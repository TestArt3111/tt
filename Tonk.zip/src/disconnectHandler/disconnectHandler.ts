import { Socket } from "socket.io";

import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { io } from "../connection/socket";
import { getUser } from "../common/gameRedisOperations/user";
import { disconnectUserAdd } from "../bull/add/disconnectUser";
import { getTable } from "../common/gameRedisOperations/table";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { removeUserFromTable } from "../common/gameActivity/removeUserFromTable";
import { applyMatchMakingLock, removeMatchMakingLock } from "../common/locks/matchMaking";

const disconnectHandler = async (socket: Socket) => {

    const matchMakingLock = await applyMatchMakingLock("disconnectHandler", socket.handshake.auth?.bootValue, 2);

    const tableLock = await applyTableLock("disconnectHandler", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("disconnectHandler", { socketData: socket.handshake.auth });

        if (!socket.handshake.auth?.userId) { throw new Error("UserId Not Found !!!"); };

        const userData = await getUser(socket.handshake.auth?.userId);

        if (io.sockets.sockets.get(userData.socketId)) { throw new Error("User Socket Is Connected !!!"); };

        if (!userData?.tableId || userData?.tableId === CONSTANTS.COMMON.DISCONNECTED || userData?.tableId === CONSTANTS.COMMON.TURN_MISSED) { throw new Error("User Is Not In Playing State !!!"); };

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (!tableData.users.find(e => e.userId === socket.handshake.auth?.userId)) { throw new Error("User Not Available In This Table !!!"); };

        if ((tableData.isRoundTimer || !tableData.isGameStart) && !tableData.isTableLock) {

            await removeUserFromTable("", tableData.tableId, userData.userId, tableData.roundNum === 1 ? "" : CONSTANTS.COMMON.DISCONNECTED);

        } else { await disconnectUserAdd(socket.handshake.auth?.userId, socket.handshake.auth?.tableId, socket.handshake.auth?.bootValue); };

    } catch (error: any) {

        logger.errorLog("disconnectHandler Error : ", error);

    } finally {

        if (matchMakingLock) { await removeMatchMakingLock("disconnectHandler", matchMakingLock); };

        if (tableLock) { await removeTableLock("disconnectHandler", tableLock); };

    };
};

export { disconnectHandler };