import { logger } from "../logger/logger";
import { redisClient } from "../connection/redis";

const setData = async (key: string, data: object) => {

    try {

        logger.log("setData", { key, data });

        await redisClient.set(key, JSON.stringify(data));

    } catch (error: any) {
        logger.errorLog("setData Error : ", error);
    };
};

const getData = async (key: string) => {

    try {

        logger.log("getData", { key });

        const data = await redisClient.get(key);

        return data ? JSON.parse(data) : "";

    } catch (error: any) {
        logger.errorLog("getData Error : ", error);
    };
};

const deleteData = async (key: string) => {

    try {

        logger.log("deleteData", { key });

        await redisClient.del(key);

    } catch (error: any) {
        logger.errorLog("deleteData Error : ", error);
    };
};

const addToArray = async (key: string, data: string) => {

    try {

        logger.log("addToArray", { key, data });

        await redisClient.lPush(key, data);

    } catch (error: any) {
        logger.errorLog("addToArray Error : ", error);
    };
};

const getArray = async (key: string) => {

    try {

        logger.log("getArray", { key });

        const data = await redisClient.lRange(key, 0, -1);

        return data;

    } catch (error: any) {
        logger.errorLog("getArray Error : ", error);
    };
};

const removeFromArray = async (key: string, value: string) => {

    try {

        logger.log("removeFromArray", { key, value });

        await redisClient.lRem(key, 1, value);

    } catch (error: any) {
        logger.errorLog("removeFromArray Error : ", error);
    };
};

export { setData, getData, deleteData, addToArray, getArray, removeFromArray };