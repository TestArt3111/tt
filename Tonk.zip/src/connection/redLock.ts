import Redlock, { Lock } from "redlock";
import { RedisOptions, Redis } from "ioredis";

import { config } from "../config";
import { logger } from "../logger/logger";

let redLock: any;

const redlockConnection = async () => {

    try {

        const redisOptions: RedisOptions = {

            host: config.redis.REDIS_HOST,
            port: config.redis.REDIS_PORT,
            password: config.redis.REDIS_PASSWORD,
            db: config.redis.REDIS_DATABASE_NUMBER

        };

        const redisClient = new Redis(redisOptions);

        redLock = new Redlock([redisClient], {
            driftFactor: 0.01,
            retryCount: -1,
            retryDelay: 25,
            retryJitter: 20,
            // automaticExtensionThreshold: 500
        });

        redLock.on("error", async (error: any) => { logger.errorLog("RedLock Error : ", error); });

        redLock.on("lockError", async (error: any) => { logger.errorLog("RedLock Lock Error : ", error); });

        redLock.on("unlockError", async (error: any) => { logger.errorLog("RedLock Unlock Error : ", error); });

        console.log("redLock Connected !!!");

    } catch (error: any) {
        console.log("redlockConnection Error : ", error);
    };
};

const applyLock = async (path: string, lockId: string, delay: number) => {

    try {

        logger.log("applyLock", { path, lockId, delay });

        const Lock: Lock = await redLock.acquire([lockId], (delay * 1000));

        return Lock;

    } catch (error: any) {
        logger.errorLog("applyLock Error : ", error);
    };
};

export { redlockConnection, applyLock };