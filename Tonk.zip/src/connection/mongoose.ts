import mongoose from "mongoose";

import { config } from "../config";

const mongooseConnection = async () => {

    try {

        await mongoose.connect(config.mongoUrl).then(() => { console.log("Mongo Connected !!!"); });

    } catch (error: any) {
        console.log("mongooseConnection Error : ", error);
    };
};

export { mongooseConnection };