import { eventEmitter } from "./emitter";
import { CONSTANTS } from "../constants";
import { sendToRoom } from "../common/socketOperations/sendToRoom";
import { sendToSocket } from "../common/socketOperations/sendToSocket";

const emitterON = async () => {

    try {

        console.log("emitterON Done !!!");

        const {

            HIT,
            TEST,
            ALERT,
            KNOCK,
            SIGNUP,
            SPREAD,
            REJOIN,
            DEFAULT,
            WINNING,
            WAITING,
            MY_CARDS,
            WIN_TYPE,
            TURN_INFO,
            PICK_CARD,
            HEART_BEAT,
            GAME_START,
            TABLE_LOCK,
            JOIN_TABLE,
            KNOCK_LOCK,
            SORT_CARDS,
            THROW_CARD,
            LEAVE_TABLE,
            ERROR_POPUP,
            CARD_POINTS,
            TURN_MISSED,
            COLLECT_BOOT,
            SELF_BALANCE,
            ACTIVE_PLAYERS,

        } = CONSTANTS.EVENTS_NAME;

        // * Send To Socket

        eventEmitter.on(TEST, async (data) => { await sendToSocket(TEST, data); });

        eventEmitter.on(ALERT, async (data) => { await sendToSocket(ALERT, data); });

        eventEmitter.on(SIGNUP, async (data) => { await sendToSocket(SIGNUP, data); });

        eventEmitter.on(REJOIN, async (data) => { await sendToSocket(REJOIN, data); });

        eventEmitter.on(DEFAULT, async (data) => { await sendToSocket(DEFAULT, data); });

        eventEmitter.on(MY_CARDS, async (data) => { await sendToSocket(MY_CARDS, data); });
        
        eventEmitter.on(SORT_CARDS, async (data) => { await sendToSocket(SORT_CARDS, data); });

        eventEmitter.on(HEART_BEAT, async (data) => { await sendToSocket(HEART_BEAT, data); });

        eventEmitter.on(ERROR_POPUP, async (data) => { await sendToSocket(ERROR_POPUP, data); });

        eventEmitter.on(CARD_POINTS, async (data) => { await sendToSocket(CARD_POINTS, data); });

        eventEmitter.on(SELF_BALANCE, async (data) => { await sendToSocket(SELF_BALANCE, data); });

        // * Send To Room

        eventEmitter.on(HIT, async (data) => { await sendToRoom(HIT, data); });

        eventEmitter.on(KNOCK, async (data) => { await sendToRoom(KNOCK, data); });

        eventEmitter.on(SPREAD, async (data) => { await sendToRoom(SPREAD, data); });
        
        eventEmitter.on(WAITING, async (data) => { await sendToRoom(WAITING, data); });

        eventEmitter.on(WINNING, async (data) => { await sendToRoom(WINNING, data); });

        eventEmitter.on(WIN_TYPE, async (data) => { await sendToRoom(WIN_TYPE, data); });

        eventEmitter.on(TURN_INFO, async (data) => { await sendToRoom(TURN_INFO, data); });

        eventEmitter.on(PICK_CARD, async (data) => { await sendToRoom(PICK_CARD, data); });

        eventEmitter.on(JOIN_TABLE, async (data) => { await sendToRoom(JOIN_TABLE, data); });

        eventEmitter.on(KNOCK_LOCK, async (data) => { await sendToRoom(KNOCK_LOCK, data); });

        eventEmitter.on(GAME_START, async (data) => { await sendToRoom(GAME_START, data); });

        eventEmitter.on(TABLE_LOCK, async (data) => { await sendToRoom(TABLE_LOCK, data); });

        eventEmitter.on(THROW_CARD, async (data) => { await sendToRoom(THROW_CARD, data); });

        eventEmitter.on(LEAVE_TABLE, async (data) => { await sendToRoom(LEAVE_TABLE, data); });

        eventEmitter.on(TURN_MISSED, async (data) => { await sendToRoom(TURN_MISSED, data); });

        eventEmitter.on(COLLECT_BOOT, async (data) => { await sendToRoom(COLLECT_BOOT, data); });

        eventEmitter.on(ACTIVE_PLAYERS, async (data) => { await sendToRoom(ACTIVE_PLAYERS, data); });

    } catch (error) {
        console.log("emitterON Error : ", error);
    };
};

export { emitterON };