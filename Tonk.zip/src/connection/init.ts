import { config } from "../config";
import { emitterON } from "./emitterOn";
import { redisConnection } from "./redis";
import { httpsConnection } from "./https";
import { socketConnection } from "./socket";
import { redlockConnection } from "./redLock";
import { mongooseConnection } from "./mongoose";

const initialize = async () => {

    try {

        console.log("Environment", process.env.ENVIRONMENT);

        console.log("Config", config);

        await emitterON();

        await redisConnection();

        await redlockConnection();

        await httpsConnection();

        await socketConnection();

        await mongooseConnection();

    } catch (error) {
        console.log("initialize Error : ", error);
    };
};

export { initialize };