import events, { EventEmitter } from "events";

const eventEmitter: EventEmitter = new events();

export { eventEmitter };