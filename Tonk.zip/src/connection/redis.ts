import ioRedis, { RedisOptions, Redis } from "ioredis";
import { createClient, RedisClientOptions } from "redis";

import { config } from "../config";

interface CustomIORedis extends Redis { };

let redisClient: ReturnType<typeof createClient>, pubClient: CustomIORedis, subClient: CustomIORedis;

const redisConnection = async () => {

    try {

        const redisOptions: RedisClientOptions = {

            socket: {
                host: config.redis.REDIS_HOST,
                port: config.redis.REDIS_PORT
            },
            password: config.redis.REDIS_PASSWORD,
            database: config.redis.REDIS_DATABASE_NUMBER
        };

        const pubSubRedisOptions: RedisOptions = {

            host: config.redisPubSub.PUBSUB_REDIS_HOST,
            port: config.redisPubSub.PUBSUB_REDIS_PORT,
            password: config.redisPubSub.PUBSUB_REDIS_PASSWORD,
            db: config.redisPubSub.PUBSUB_REDIS_DATABASE_NUMBER

        };

        pubClient = new ioRedis(pubSubRedisOptions);
        subClient = new ioRedis(pubSubRedisOptions);

        redisClient = createClient(redisOptions);

        redisClient.on("error", (error: any) => { console.log(`Redis Error : ${error}`); });

        await redisClient.connect().then(() => { console.log("redis Connected !!!"); redisClient.flushDb(); });

    } catch (error) {
        console.log("redisConnection Error : ", error);
    };
};

export { redisConnection, redisClient, pubClient, subClient };