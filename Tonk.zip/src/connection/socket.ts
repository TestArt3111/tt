import { Server, Socket } from "socket.io";
import { createAdapter } from "@socket.io/redis-adapter";

import { httpsServer } from "./https";
import { logger } from "../logger/logger";
import { pubClient, subClient } from "./redis";
import { eventCases } from "../eventCases/eventCases";
import { disconnectHandler } from "../disconnectHandler/disconnectHandler";

interface CustomIO extends Server { };

let io: CustomIO;

const socketConnection = async () => {

    try {

        io = new Server(httpsServer, { pingTimeout: 4000, pingInterval: 1500, cors: { origin: "*" } });

        io.adapter(createAdapter(pubClient, subClient));

        io.on("connection", async (socket: Socket) => {

            logger.log("SocketConnection", socket.id);

            await eventCases(socket);

            socket.on("disconnect", async (reason: string) => {

                logger.log("Disconnect : ", socket.id);

                logger.log("Disconnect Reason : ", reason);

                await disconnectHandler(socket);

                socket.handshake.auth = {};

            });

        });

        console.log("socket Connected !!!");

    } catch (error: any) {
        console.log("socketConnection Error : ", error);
    };
};

export { socketConnection, io };