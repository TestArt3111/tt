import cors from "cors";
import http from "http";
import https from "https";
import bodyParser from 'body-parser';
import express, { Express } from "express";
import { existsSync, readFileSync } from "fs";

import { config } from "./../config";
import { router } from "../api/routes/route";
import { User } from "../api/models/user";

let httpsServer: (https.Server | http.Server);

const httpsConnection = async () => {

    try {

        const app: Express = express();

        app.use(bodyParser.urlencoded({ extended: false }));
        app.use(bodyParser.json());
        app.use(cors());
        app.use(router);

        if (existsSync(config.certPath) && existsSync(config.keyPath)) {

            const keyData = readFileSync(config.keyPath, "utf-8");
            const certData = readFileSync(config.certPath, "utf-8");

            httpsServer = https.createServer({ key: keyData, cert: certData }, app);

            httpsServer.listen(config.serverPort, () => console.log(`HTTPS Server listening on port ${config.serverPort} !!!`));

        } else {

            httpsServer = http.createServer(app);

            httpsServer.listen(config.serverPort, () => console.log(`HTTP Server listening on port ${config.serverPort} !!!`));

        };

        app.get("/", (req, res) => { res.send("TONK !!!"); });

        app.get("/test", (req, res) => { res.send("TONK !!!"); });

        app.get("/deleteUser", async (req, res) => {

            await User.deleteOne({ userName: req.query.name });

            res.send(`Deleted User : ${req.query.name}`);

        });

    } catch (error: any) {
        console.log("httpsConnection Error : ", error);
    };
};

export { httpsConnection, httpsServer };