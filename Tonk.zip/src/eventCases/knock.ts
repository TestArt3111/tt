import { Socket } from "socket.io";
import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { win } from "../common/gameActivity/win";
import { eventEmitter } from "../connection/emitter";
import { getTable } from "../common/gameRedisOperations/table";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const knock = async (socket: Socket, knockData: object) => {

    const tableLock = await applyTableLock("knock", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("knock", { knockData });

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (tableData.currentTurn !== socket.handshake.auth?.seatIndex) { throw new Error("It's Not Your Turn !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (userInTableData.knockLock !== 0) { throw new Error("You Can't Able To Konck !!!"); };

        await setUserInTable(tableData.tableId, userInTableData.userId, { ...userInTableData, isKnock: true });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.KNOCK, { roomId: tableData.tableId, data: { userId: userInTableData.userId } });

        await win(tableData.tableId, CONSTANTS.WIN_TYPES.KNOCK);

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("knock Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("knock", tableLock); };

    };
};

export { knock };