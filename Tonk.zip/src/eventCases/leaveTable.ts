import { Socket } from "socket.io";

import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { eventEmitter } from "../connection/emitter";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { removeUserFromTable } from "../common/gameActivity/removeUserFromTable";
import { applyMatchMakingLock, removeMatchMakingLock } from "../common/locks/matchMaking";

const leaveTable = async (socket: Socket, leaveData: object) => {

    const matchMakingLock = await applyMatchMakingLock("leaveTable", socket.handshake.auth?.bootValue, 2);

    const tableLock = await applyTableLock("leaveTable", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("leaveTable", { socketData: socket.handshake.auth, leaveData });

        await removeUserFromTable(socket.id, socket.handshake.auth?.tableId, socket.handshake.auth?.userId, "");

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("leaveTable Error : ", error);

    } finally {

        if (matchMakingLock) { await removeMatchMakingLock("leaveTable", matchMakingLock); };

        if (tableLock) { await removeTableLock("leaveTable", tableLock); };

    };
};

export { leaveTable };