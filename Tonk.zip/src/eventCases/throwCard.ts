import { Socket } from "socket.io";

import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { eventEmitter } from "../connection/emitter";
import { validateThrowCard } from "../validation/throwCard";
import { ThrowCardInterface } from "../interfaces/throwCard";
import { changeTurn } from "../common/gameActivity/changeTurn";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { getTable, setTable } from "../common/gameRedisOperations/table";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const throwCard = async (socket: Socket, throwCardData: ThrowCardInterface) => {

    const tableLock = await applyTableLock("throwCard", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("throwCard", { throwCardData });

        const validateError = await validateThrowCard(throwCardData);

        if (validateError) { throw new Error(validateError); };

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (!CONSTANTS.CARDS.includes(throwCardData.card)) { throw new Error("Wrong Card !!!"); };

        if (tableData.currentTurn !== socket.handshake.auth?.seatIndex) { throw new Error("It's Not Your Turn !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (!userInTableData.lastPickCard) { throw new Error("First You Need To Pick A Card !!!"); };

        if (!userInTableData.cards.includes(throwCardData.card)) { throw new Error("This Card Is Not Available In Your Deck !!!"); };

        await setTable(tableData.tableId, { ...tableData, openCards: [throwCardData.card, ...tableData.openCards] });

        await setUserInTable(tableData.tableId, userInTableData.userId, { ...userInTableData, cards: userInTableData.cards.filter(e => e !== throwCardData.card) });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.THROW_CARD, { roomId: tableData.tableId, data: { card: throwCardData.card, seatIndex: tableData.currentTurn } });

        await changeTurn(tableData.tableId);

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("throwCard Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("throwCard", tableLock); };

    };
};

export { throwCard };