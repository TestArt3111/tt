import { Socket } from "socket.io";

import { logger } from "../logger/logger";
import { CONSTANTS } from "./../constants";
import { UserInterface } from "../interfaces/user";
import { eventEmitter } from "../connection/emitter";
import { validateSignUp } from "../validation/signUp";
import { SignUpInterface } from "../interfaces/signUp";
import { addUser } from "../common/manageUser/addUser";
import { findTable } from "../common/manageTable/findTable";
import { updateUser } from "../common/manageUser/updateUser";
import { getUser } from "../common/gameRedisOperations/user";
import { rejoinTable } from "../common/manageTable/rejoinTable";
import { disconnectUserRemove } from "../bull/remove/disconnectUser";
import { removeMatchMakingLock, applyMatchMakingLock } from "../common/locks/matchMaking";
import { User } from "../api/models/user";

const signUp = async (socket: Socket, signUpData: SignUpInterface) => {

    const matchMakingLock = await applyMatchMakingLock("signUp", signUpData?.bootValue, 2);

    try {

        logger.log("signUp", { signUpData });

        const validateError = await validateSignUp(signUpData);

        if (validateError) { throw new Error(validateError); };

        const mongoUserData = await User.findOne({ deviceId: signUpData.userId }).lean();

        if (!mongoUserData) { return eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: socket.id, data: { message: "User Not Found !!!" } }); };

        signUpData.chips = mongoUserData.chips ? mongoUserData.chips : 0;

        socket.handshake.auth.userId = signUpData?.userId;
        socket.handshake.auth.bootValue = signUpData?.bootValue;

        const user: UserInterface | void = await getUser(signUpData.userId).catch((error) => { logger.log("signUp getUser : ", error); });

        const userData = user ? await updateUser(socket, signUpData, user) : await addUser(socket, signUpData);

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.SIGNUP, { socketId: socket.id, data: userData });

        if (userData?.tableId === CONSTANTS.COMMON.DISCONNECTED || userData?.tableId === CONSTANTS.COMMON.TURN_MISSED) {

            return eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: socket.id, data: { message: `You have left the previous game before game start. Please exit and join again !!!` } });

        };

        if (userData && !(userData?.tableId && await rejoinTable(socket, userData))) {

            if (mongoUserData.isBlock) { return eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: socket.id, data: { message: "User Block !!!" } }); };

            await findTable(socket, userData);

        };

        await disconnectUserRemove(userData?.userId ?? "");

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("signUp Error : ", error);

    } finally {

        if (matchMakingLock) { await removeMatchMakingLock("signUp", matchMakingLock); };

    };
};

export { signUp };