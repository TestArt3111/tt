import { Socket } from "socket.io";

import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { eventEmitter } from "../connection/emitter";
import { validatePickCard } from "../validation/pickCard";
import { PickCardInterface } from "../interfaces/pickCard";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { getTable, setTable } from "../common/gameRedisOperations/table";
import { totalCardPoints } from "../common/gameActivity/totalCardPoints";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const pickCard = async (socket: Socket, pickCardData: PickCardInterface) => {

    const tableLock = await applyTableLock("pickCard", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("pickCard", { pickCardData });

        const validateError = await validatePickCard(pickCardData);

        if (validateError) { throw new Error(validateError); };

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (tableData.currentTurn !== socket.handshake.auth?.seatIndex) { throw new Error("It's Not Your Turn !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (userInTableData.lastPickCard) { throw new Error("Can't Able To Pick Card !!!"); };

        if (pickCardData?.openDeck && !tableData.openCards.length) { throw new Error("Can't Able To Pick Card From Empty Open Deck !!!"); };

        if (!pickCardData?.openDeck && !tableData.closeCards.length) { throw new Error("Can't Able To Pick Card From Empty Close Deck !!!"); };

        const card = pickCardData?.openDeck ? tableData.openCards.splice(0, 1)[0] : tableData.closeCards.splice(0, 1)[0];

        await setUserInTable(tableData.tableId, userInTableData.userId, { ...userInTableData, lastPickCard: card, cards: [...userInTableData.cards, card] });

        await setTable(tableData.tableId, { ...tableData });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.PICK_CARD, { roomId: tableData.tableId, data: { card, seatIndex: tableData.currentTurn, closeCards: tableData.closeCards.length, openDeck: pickCardData?.openDeck } });

        await totalCardPoints([card, ...userInTableData.cards], userInTableData.socketId);

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("pickCard Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("pickCard", tableLock); };

    };
};

export { pickCard };