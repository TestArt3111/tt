import { Socket } from "socket.io";

import { hit } from "./hit";
import { knock } from "./knock";
import { alert } from "./alert";
import { signUp } from "./signUp";
import { spread } from "./spread";
import { pickCard } from "./pickCard";
import { throwCard } from "./throwCard";
import { sortCards } from "./sortCards";
import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { leaveTable } from "./leaveTable";
import { eventEmitter } from "../connection/emitter";

const eventCases = async (socket: Socket) => {

    try {

        socket.onAny(async (eventName: string, payload: any, ack) => {

            // logger.log("eventCases Data : ", { eventName, payload });

            const {

                HIT,
                TEST,
                KNOCK,
                SIGNUP,
                SPREAD,
                DEFAULT,
                PICK_CARD,
                HEART_BEAT,
                THROW_CARD,
                SORT_CARDS,
                LEAVE_TABLE,
                ALERT_CONFIRMATION

            } = CONSTANTS.EVENTS_NAME;

            if (typeof payload === "string") { payload = JSON.parse(payload); };

            switch (eventName) {

                case TEST:
                    logger.log(`eventCases ${TEST}`, payload);
                    eventEmitter.emit(TEST, { socketId: socket.id, data: payload });
                    break;

                case HEART_BEAT:
                    // logger.log(`eventCases ${HEART_BEAT}`, payload);
                    eventEmitter.emit(HEART_BEAT, { socketId: socket.id, data: payload });
                    break;

                case SIGNUP:
                    logger.log(`eventCases ${SIGNUP}`, payload);
                    await signUp(socket, payload);
                    break;

                case PICK_CARD:
                    logger.log(`eventCases ${PICK_CARD}`, payload);
                    await pickCard(socket, payload);
                    break;

                case THROW_CARD:
                    logger.log(`eventCases ${THROW_CARD}`, payload);
                    await throwCard(socket, payload);
                    break;

                case SPREAD:
                    logger.log(`eventCases ${SPREAD}`, payload);
                    await spread(socket, payload);
                    break;

                case HIT:
                    logger.log(`eventCases ${HIT}`, payload);
                    await hit(socket, payload);
                    break;

                case KNOCK:
                    logger.log(`eventCases ${KNOCK}`, payload);
                    await knock(socket, payload);
                    break;

                case SORT_CARDS:
                    logger.log(`eventCases ${SORT_CARDS}`, payload);
                    await sortCards(socket, payload);
                    break;

                case LEAVE_TABLE:
                    logger.log(`eventCases ${LEAVE_TABLE}`, payload);
                    await leaveTable(socket, payload);
                    break;

                case ALERT_CONFIRMATION:
                    logger.log(`eventCases ${ALERT_CONFIRMATION}`, payload);
                    await alert(socket, payload);
                    break;

                default:
                    logger.log(`eventCases ${DEFAULT}`, payload);
                    eventEmitter.emit(DEFAULT, { socketId: socket.id, data: { message: CONSTANTS.COMMON.UNKNOWN_EVENT } });
                    break;

            };

        });

    } catch (error: any) {
        console.log("eventCases Error : ", error);
    };
};

export { eventCases };