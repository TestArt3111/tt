import { Socket } from "socket.io";

import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { eventEmitter } from "../connection/emitter";
import { SortCardsInterface } from "../interfaces/sortCards";
import { getTable } from "../common/gameRedisOperations/table";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const sortCards = async (socket: Socket, sortCardsData: SortCardsInterface) => {

    const tableLock = await applyTableLock("sortCards", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("sortCards", { sortCardsData });

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (!sortCardsData.cards.every(e => CONSTANTS.CARDS.includes(e))) { throw new Error("Wrong Card !!!"); };

        if (!sortCardsData?.cards.every(e => userInTableData.cards.includes(e))) { throw new Error("This Card Is Not Available In Your Deck !!!"); };

        if (new Set(sortCardsData.cards).size !== userInTableData.cards.length || sortCardsData.cards.length !== userInTableData.cards.length) { throw new Error("Provide Valid Cards !!!"); };

        await setUserInTable(tableData.tableId, socket.handshake.auth?.userId, { ...userInTableData, cards: sortCardsData.cards });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.SORT_CARDS, { socketId: userInTableData.socketId, data: { ...sortCardsData } });

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("sortCards Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("sortCards", tableLock); };

    };
};

export { sortCards };