import { Socket } from "socket.io";

import { config } from "../config";
import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { win } from "../common/gameActivity/win";
import { eventEmitter } from "../connection/emitter";
import { validateSpread } from "../validation/spread";
import { SpreadInterface } from "../interfaces/spread";
import { checkSet } from "../common/gameActivity/checkSet";
import { knockLock } from "../common/gameActivity/knockLock";
import { getTable } from "../common/gameRedisOperations/table";
import { checkSequence } from "../common/gameActivity/checkSequence";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { totalCardPoints } from "../common/gameActivity/totalCardPoints";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const spread = async (socket: Socket, spreadData: SpreadInterface) => {

    const tableLock = await applyTableLock("spread", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("spread", { spreadData });

        const validateError = await validateSpread(spreadData);

        if (validateError) { throw new Error(validateError); };

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (!spreadData.cards.every(e => CONSTANTS.CARDS.includes(e))) { throw new Error("Wrong Card !!!"); };

        if (tableData?.currentTurn !== socket.handshake.auth?.seatIndex) { throw new Error("It's Not Your Turn !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (!userInTableData.lastPickCard) { throw new Error("First You Need To Pick A Card !!!"); };

        if (!spreadData?.cards.every(e => userInTableData.cards.includes(e))) { throw new Error("This Card Is Not Available In Your Deck !!!"); };

        const isSet = await checkSet(spreadData.cards);

        const isSequence = await checkSequence(spreadData.cards);

        if (isSet === undefined || isSequence === undefined) { throw new Error("Failed To Validate Spread !!!"); };

        if (!isSet && !isSequence?.isLowSequence && !isSequence?.isHighSequence) { throw new Error("No Valid Spread !!!"); };

        const hand = isSequence?.isLowSequence
            ? spreadData.cards.sort((a, b) => Number(a.split("-")[1]) - Number(b.split("-")[1]))
            : spreadData.cards
                .map(e => Number(e.split("-")[1]) === 1 ? `${e.split("-")[0]}-14` : e)
                .sort((a, b) => Number(a.split("-")[1]) - Number(b.split("-")[1]))
                .map(e => Number(e.split("-")[1]) === 14 ? `${e.split("-")[0]}-1` : e);

        const cards = userInTableData.cards.filter(e => !spreadData.cards.includes(e));

        await setUserInTable(tableData.tableId, userInTableData.userId, {
            ...userInTableData,
            isSpread: true,
            cards: cards,
            hands: [...userInTableData.hands, hand],
            settledCard: userInTableData.settledCard + spreadData.cards.length,
            knockLock: Math.min(spreadData.cards.length + userInTableData.knockLock, CONSTANTS.COMMON.MAX_KONCK_LOCK_COUNT),
        });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.SPREAD, { roomId: tableData.tableId, data: { hand, seatIndex: tableData.currentTurn, isSpread: cards.length !== 0 } });

        await totalCardPoints(cards, userInTableData.socketId);

        if (cards.length === 0) {

            await win(tableData.tableId, (userInTableData.settledCard + spreadData.cards.length) > config.gamePlay.DISTRIBUTE_CARDS_LIMIT ? CONSTANTS.WIN_TYPES.TONKS_OUT : CONSTANTS.WIN_TYPES.TONK);

        } else { await knockLock(tableData.tableId, tableData.users); };

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("spread Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("spread", tableLock); };

    };
};

export { spread };