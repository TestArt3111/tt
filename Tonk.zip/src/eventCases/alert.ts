import { Socket } from "socket.io";

import { logger } from "../logger/logger";
import { UserInterface } from "../interfaces/user";
import { getUser, setUser } from "../common/gameRedisOperations/user";

const alert = async (socket: Socket, alertData: object) => {

    try {

        logger.log("alert", { socketData: socket.handshake.auth, alertData });

        const userData: UserInterface | void = await getUser(socket.handshake.auth?.userId).catch((error) => { logger.log("alert getUser : ", error); });

        if (userData && userData.tableId !== "") { await setUser(userData.userId, { ...userData, tableId: "" }); };

    } catch (error: any) {
        logger.errorLog("alert Error : ", error);
    };
};

export { alert };