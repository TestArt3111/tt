import { Socket } from "socket.io";

import { config } from "../config";
import { CONSTANTS } from "../constants";
import { logger } from "../logger/logger";
import { validateHit } from "../validation/hit";
import { win } from "../common/gameActivity/win";
import { HitInterface } from "../interfaces/hit";
import { eventEmitter } from "../connection/emitter";
import { checkSet } from "../common/gameActivity/checkSet";
import { knockLock } from "../common/gameActivity/knockLock";
import { getTable } from "../common/gameRedisOperations/table";
import { checkSequence } from "../common/gameActivity/checkSequence";
import { applyTableLock, removeTableLock } from "../common/locks/table";
import { totalCardPoints } from "../common/gameActivity/totalCardPoints";
import { getUserInTable, setUserInTable } from "../common/gameRedisOperations/userInTable";

const hit = async (socket: Socket, hitData: HitInterface) => {

    const tableLock = await applyTableLock("hit", socket.handshake.auth?.tableId, 2);

    try {

        logger.log("hit", { hitData });

        const validateError = await validateHit(hitData);

        if (validateError) { throw new Error(validateError); };

        const tableData = await getTable(socket.handshake.auth?.tableId);

        if (tableData.isWinning) { throw new Error("You're already in a winning state! No further actions needed !!!"); };

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (hitData.cards.length > 2 || !hitData.cards.length) { throw new Error("No Valid Hit !!!"); };

        if (!hitData.cards.every(e => CONSTANTS.CARDS.includes(e))) { throw new Error("Wrong Card !!!"); };

        if (tableData?.currentTurn !== socket.handshake.auth?.seatIndex) { throw new Error("It's Not Your Turn !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, socket.handshake.auth?.userId);

        if (!userInTableData.lastPickCard) { throw new Error("First You Need To Pick A Card !!!"); };

        if (!hitData.cards.every(e => userInTableData.cards.includes(e))) { throw new Error("This Card Is Not Available In Your Deck !!!"); };

        const opponentUser = tableData.users.find(e => e.userId === hitData.opponentId);

        if (!opponentUser) { throw new Error("Opponent Not Found With It's UserId !!!"); };

        const opponentUserInTableData = hitData.opponentId === userInTableData.userId ? userInTableData : await getUserInTable(tableData.tableId, opponentUser?.userId);

        if (!opponentUserInTableData.hands.length) { throw new Error("Opponent Doesn't Have A Hand !!!"); };

        for (let i = 0; i < opponentUserInTableData.hands.length; i++) {

            const hitHand = [...opponentUserInTableData.hands[i], ...hitData.cards];

            const isSet = await checkSet(hitHand);

            const isSequence = await checkSequence(hitHand);

            if (isSet === undefined || isSequence === undefined) { throw new Error("Failed To Validate Spread !!!"); };

            if (!isSet && !isSequence?.isLowSequence && !isSequence?.isHighSequence) { continue; };

            const hand = isSequence?.isLowSequence
                ? hitHand.sort((a, b) => Number(a.split("-")[1]) - Number(b.split("-")[1]))
                : hitHand
                    .map(e => Number(e.split("-")[1]) === 1 ? `${e.split("-")[0]}-14` : e)
                    .sort((a, b) => Number(a.split("-")[1]) - Number(b.split("-")[1]))
                    .map(e => Number(e.split("-")[1]) === 14 ? `${e.split("-")[0]}-1` : e);

            const cards = userInTableData.cards.filter(e => !hitData.cards.includes(e));

            if (hitData.opponentId === userInTableData.userId) {

                await setUserInTable(tableData.tableId, userInTableData.userId, {
                    ...userInTableData,
                    isHit: true,
                    cards: cards,
                    settledCard: userInTableData.settledCard + 1,
                    hands: opponentUserInTableData.hands.map((e, index) => index === i ? hand : e),
                    knockLock: Math.min(userInTableData.knockLock + hitData.cards.length, CONSTANTS.COMMON.MAX_KONCK_LOCK_COUNT),
                });

            } else {

                await setUserInTable(tableData.tableId, userInTableData.userId, {
                    ...userInTableData,
                    isHit: true,
                    cards: cards,
                    settledCard: userInTableData.settledCard + 1,
                    knockLock: Math.min(userInTableData.knockLock + hitData.cards.length, CONSTANTS.COMMON.MAX_KONCK_LOCK_COUNT),
                });

                await setUserInTable(tableData.tableId, opponentUser?.userId, {
                    ...opponentUserInTableData,
                    hands: opponentUserInTableData.hands.map((e, index) => index === i ? hand : e),
                    knockLock: Math.min(opponentUserInTableData.knockLock + hitData.cards.length, CONSTANTS.COMMON.MAX_KONCK_LOCK_COUNT),
                });

            };

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.HIT, {
                roomId: tableData.tableId,
                data: {
                    hand,
                    cards: hitData.cards,
                    seatIndex: tableData.currentTurn,
                    userId: userInTableData.userId,
                    opponentId: opponentUserInTableData.userId,
                    opponentSeatIndex: opponentUserInTableData.seatIndex,
                    listCount: hitData.listCount,
                    isHit: cards.length !== 0
                }
            });

            await totalCardPoints(cards, userInTableData.socketId);

            if (cards.length === 0) {

                await win(tableData.tableId, userInTableData.settledCard > config.gamePlay.DISTRIBUTE_CARDS_LIMIT ? CONSTANTS.WIN_TYPES.TONKS_OUT : CONSTANTS.WIN_TYPES.TONK);

            } else { await knockLock(tableData.tableId, tableData.users); };

            return;

        };

        throw new Error("No Valid Hit !!!");

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("hit Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("hit", tableLock); };

    };
};

export { hit };