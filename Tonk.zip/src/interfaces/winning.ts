export interface WinningInterface {

    winType: string,
    isDraw: boolean,
    winArr: Array<WinArrayInterface>

};

export interface WinArrayInterface {

    userId: string,
    userName: string,
    userProfile: string,
    cards: Array<string>,
    cardWisePoints: Array<number>,
    totalPoints: number,
    isKnock: boolean
    isLeave: boolean,
    isWinner: boolean,
    isPenalty: boolean,
    amount: number

};