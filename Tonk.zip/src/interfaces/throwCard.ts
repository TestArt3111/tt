export interface ThrowCardInterface {

    card: string

};