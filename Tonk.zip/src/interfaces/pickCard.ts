export interface PickCardInterface {

    openDeck: boolean

};