export interface HitInterface {

    cards: Array<string>,
    opponentId: string,
    listCount: number

};