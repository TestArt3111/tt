export interface TableInterface {

    tableId: string,
    roundNum: number,
    bootValue: number,
    lobbyId: string,
    reward: number,
    currentTurn: number,
    dealer: number,

    users: Array<TableUsersInterface>,

    openCards: Array<string>,
    closeCards: Array<string>,

    isWinning: boolean,
    isGameStart: boolean,
    isTableLock: boolean,
    isRoundTimer: boolean,
    isRoundStart: boolean,

    cardDelay: boolean,

};

export interface TableUsersInterface {

    userId: string,
    userName: string,
    userProfile: string,
    seatIndex: number,
    isLeave: boolean

};