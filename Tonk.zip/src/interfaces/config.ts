export interface ConfigInterface {

    redis: RedisInterface,
    redisPubSub: PubSubRedisInterface,
    mongoUrl: string,
    serverPort: number,
    gamePlay: GamePlayInterface,
    keyPath: string,
    certPath: string
    jwtSecretKey: string
    
};

interface RedisInterface {

    REDIS_HOST: string,
    REDIS_PORT: number,
    REDIS_PASSWORD: string,
    REDIS_DATABASE_NUMBER: number,

};

interface PubSubRedisInterface {

    PUBSUB_REDIS_HOST: string,
    PUBSUB_REDIS_PORT: number,
    PUBSUB_REDIS_PASSWORD: string,
    PUBSUB_REDIS_DATABASE_NUMBER: number,

};

interface GamePlayInterface {

    LOG: boolean,

    MAX_USERS: number,
    DISTRIBUTE_CARDS_LIMIT: number,
    TURN_MISS_COUNT: number,

    // ^ Timers

    GAME_START_TIMER: number,
    TABLE_LOCK_TIMER: number,
    USER_TURN_TIMER: number,
    RETURN_TO_TABLE_TIMER: number,

    // ^ Card Points

    KING_POINT: number,
    QUEEN_POINT: number,
    JACK_POINT: number,

    AUTO_WIN: boolean,
    AUTO_WIN_SCORES: Array<number>,

    TONK_OUT_PENALTY: boolean,
    KNOCK_PENALTY: boolean,

};