export interface UserInTableInterface {

    userId: string,
    tableId: string,
    seatIndex: number,
    socketId: string,
    userScore: number,
    turnMiss: number,
    knockLock: number,
    settledCard: number,
    lastPickCard: string,
    cards: Array<string>,
    hands: Array<Array<string>>
    isSpread: boolean,
    isHit: boolean,
    isKnock: boolean,

};
