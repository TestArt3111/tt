export interface SpreadInterface {

    cards: Array<string>
    
};