export interface SortCardsInterface {

    cards: Array<string>
    
};