export interface SignUpInterface {

    userId: string,
    userName: string,
    userProfile: string,
    bootValue: number,
    chips: number,
    lobbyId: string

};