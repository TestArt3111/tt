export interface UserInterface {

    userId: string,
    userName: string,
    userProfile: string,
    bootValue: number,
    chips: number
    socketId: string,
    tableId: string,
    lobbyId: string

};