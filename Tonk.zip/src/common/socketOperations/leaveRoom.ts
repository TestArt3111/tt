import { Socket } from "socket.io";

import { logger } from "../../logger/logger";

const leaveRoom = async (socket: Socket, roomId: string) => {

    try {

        logger.log("leaveRoom", { roomId });

        await socket.leave(roomId);

    } catch (error: any) {
        logger.errorLog("leaveRoom Error : ", error);
    };
};

export { leaveRoom };