import { io } from "../../connection/socket";
import { logger } from "../../logger/logger";

const sendToRoom = async (EVENT: string, Data: any) => {

    try {

        const { roomId, data } = Data;

        logger.log("sendToRoom", { EVENT, data });

        io.to(roomId).emit(EVENT, JSON.stringify({ ...data }));

    } catch (error: any) {
        logger.errorLog("sendToRoom Error : ", error);
    };
};

export { sendToRoom };