import { io } from "../../connection/socket";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";

const sendToSocket = async (EVENT: string, Data: any) => {

    try {

        const { socketId, data } = Data;

        if (CONSTANTS.EVENTS_NAME.HEART_BEAT !== EVENT) { logger.log("sendToSocket", { EVENT, data }); };

        io.to(socketId).emit(EVENT, JSON.stringify({ ...data }));

    } catch (error: any) {
        logger.errorLog("sendToSocket Error : ", error);
    };
};

export { sendToSocket };