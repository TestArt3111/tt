import { Socket } from "socket.io";

import { logger } from "../../logger/logger";

const joinRoom = async (socket: Socket, roomId: string) => {

    try {

        logger.log("joinRoom", { roomId });

        await socket.join(roomId);

    } catch (error: any) {
        logger.errorLog("joinRoom Error : ", error);
    };
};

export { joinRoom };