import { Socket } from "socket.io";

import { logger } from "../../logger/logger";
import { dummyUser } from "../dummyData/user";
import { setUser } from "../gameRedisOperations/user";
import { SignUpInterface } from "../../interfaces/signUp";

const addUser = async (socket: Socket, signUpData: SignUpInterface) => {

    try {

        logger.log("addUser", { signUpData });

        const userData = await dummyUser(signUpData, socket.id, "");

        await setUser(signUpData.userId, userData);

        return userData;

    } catch (error: any) {
        logger.errorLog("addUser Error : ", error);
    };
};

export { addUser };