import { Socket } from "socket.io";

import { logger } from "../../logger/logger";
import { dummyUser } from "../dummyData/user";
import { UserInterface } from "../../interfaces/user";
import { setUser } from "../gameRedisOperations/user";
import { SignUpInterface } from "../../interfaces/signUp";

const updateUser = async (socket: Socket, signUpData: SignUpInterface, user: UserInterface) => {

    try {

        logger.log("updateUser", { signUpData, user });

        const userData = await dummyUser(signUpData, socket.id, user.tableId);

        await setUser(signUpData.userId, userData);

        return userData;

    } catch (error: any) {
        logger.errorLog("updateUser Error : ", error);
    };
};

export { updateUser };