import { UserInTableInterface } from "../../interfaces/userInTable";

const dummyUserInTable = async (userId: string, tableId: string, seatIndex: number, socketId: string): Promise<UserInTableInterface> => {

    return {

        userId,
        tableId,
        seatIndex,
        socketId,
        userScore: 0,
        turnMiss: 0,
        knockLock: 1,
        settledCard: 0,
        lastPickCard: "",
        cards: [],
        hands: [],
        isSpread: false,
        isHit: false,
        isKnock: false

    };

};

export { dummyUserInTable };