const dummyBullAddOptions = async (delay: number, jobId: string) => {

    return { delay: (delay * 1000), jobId, removeOnComplete: true };

};

export { dummyBullAddOptions };