import { UserInterface } from "../../interfaces/user";
import { SignUpInterface } from "../../interfaces/signUp";

const dummyUser = async (signUpData: SignUpInterface, socketId: string, tableId: string): Promise<UserInterface> => {

    return { ...signUpData, socketId, tableId };

};

export { dummyUser };