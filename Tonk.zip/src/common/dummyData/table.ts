import { generate } from "randomstring";

import { UserInterface } from "../../interfaces/user";
import { TableInterface } from "../../interfaces/table";

const dummyTable = async (user: UserInterface): Promise<TableInterface> => {

    return {

        tableId: generate(12),
        roundNum: 1,
        bootValue: user.bootValue,
        lobbyId: user.lobbyId,
        reward: 0,
        currentTurn: -1,
        dealer: -1,

        users: [],
        openCards: [],
        closeCards: [],

        isWinning: false,
        isGameStart: false,
        isTableLock: false,
        isRoundTimer: false,
        isRoundStart: false,

        cardDelay: false,

    };

};

export { dummyTable };