import { UserInterface } from "../../interfaces/user";
import { TableUsersInterface } from "../../interfaces/table";

const dummyTableUser = async (user: UserInterface, seatIndex: number): Promise<TableUsersInterface> => {

    return {

        userId: user.userId,
        userName: user.userName,
        userProfile: user.userProfile,
        seatIndex,
        isLeave: false

    };

};

export { dummyTableUser };