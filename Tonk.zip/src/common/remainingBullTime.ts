import { Job } from "bull";

import { logger } from "../logger/logger";

const remainingBullTime = async (job: (Job | null | undefined), decimalCount: number) => {

    try {

        logger.log("remainingBullTime", (job?.data));

        if (!job) { return 0; };

        const RemainingTime: number = (Date.now() - job.timestamp) / 1000;

        const FixedRemainingTime: number = Number(RemainingTime.toFixed(2));

        const JobDelayTimer: number = job?.opts?.delay ? job.opts.delay : 1;

        const JobDelayTimerInSecond: number = JobDelayTimer / 1000;

        const FixedJobDelayTimer: number = Number(JobDelayTimerInSecond.toFixed(2));

        const FinalRemainingTime: number = FixedJobDelayTimer - (FixedRemainingTime * 1);

        const FixedFinalRemainingTime: number = Number(FinalRemainingTime.toFixed(decimalCount));

        if (FixedFinalRemainingTime < 0) { return 0; };

        logger.log("remainingBullTime Return : ", { FixedFinalRemainingTime });

        return FixedFinalRemainingTime;

    } catch (error: any) {
        logger.errorLog("remainingBullTime Error : ", error);
    };
};

export { remainingBullTime };