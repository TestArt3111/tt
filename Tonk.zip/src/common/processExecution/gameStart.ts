import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { randomNumber } from "../randomNumber";
import { eventEmitter } from "../../connection/emitter";
import { getUser, setUser } from "../gameRedisOperations/user";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";
import { distributeCards } from "../gameActivity/distributeCards";
import { User } from "../../api/models/user";

interface GameStartInterface {
    tableId: string
};

const gameStartExecute = async (data: GameStartInterface) => {

    const tableLock = await applyTableLock("gameStartExecute", data?.tableId, 2);

    try {

        logger.log("gameStartExecute", { data });

        const tableData = await getTable(data?.tableId);

        if (!tableData.isRoundTimer) { throw new Error("First Need To Start Timer !!!"); };

        const randomNum = await randomNumber(0, (tableData.users.length - 1));

        if (randomNum === undefined) { throw new Error("Failed To Find Next Turn !!!"); };

        await setTable(tableData.tableId, {
            ...tableData,
            dealer: tableData.users[randomNum].seatIndex,
            currentTurn: tableData.users[randomNum].seatIndex,
            reward: tableData.bootValue * tableData.users.length
        });

        await Promise.all(tableData.users.map(async (tableUser) => {

            const userData = await getUser(tableUser.userId);

            await setUser(userData.userId, { ...userData, chips: userData.chips - (tableData.bootValue * 2) });

            await User.findOneAndUpdate({ deviceId: userData.userId }, { $inc: { totalGames: 1, chips: - (tableData.bootValue * 2) } });

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.SELF_BALANCE, { socketId: userData.socketId, data: { userId: userData.userId, chips: userData.chips - (tableData.bootValue * 2) } });

        }));

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.COLLECT_BOOT, { roomId: data?.tableId, data: { bootValue: tableData.bootValue, reward: tableData.bootValue * tableData.users.length } });

        await distributeCards(tableData.tableId);

    } catch (error: any) {

        logger.errorLog("gameStartExecute Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("gameStartExecute", tableLock); };

    };
};

export { gameStartExecute };