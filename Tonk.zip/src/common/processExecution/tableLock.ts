import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { eventEmitter } from "../../connection/emitter";
import { gameStartRemove } from "../../bull/remove/gameStart";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";

interface TableLockInterface {
    tableId: string
};

const tableLockExecute = async (data: TableLockInterface) => {

    const tableLock = await applyTableLock("tableLockExecute", data?.tableId, 2);

    try {

        logger.log("tableLockExecute", { data });

        const tableData = await getTable(data?.tableId);

        if (tableData.isRoundStart) { throw new Error("Need To Stop Round !!!"); };

        if (tableData.users.length > 1) {

            await setTable(tableData.tableId, { ...tableData, isTableLock: true });

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.TABLE_LOCK, { roomId: tableData.tableId, data: {} });

        } else { await gameStartRemove(tableData.tableId); };

    } catch (error: any) {

        logger.errorLog("tableLockExecute Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("tableLockExecute", tableLock); };

    };
};

export { tableLockExecute };