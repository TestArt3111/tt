import { config } from "../../config";
import { win } from "../gameActivity/win";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { turnAdd } from "../../bull/add/turn";
import { eventEmitter } from "../../connection/emitter";
import { checkAutoWin } from "../gameActivity/checkAutoWin";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";
import { totalCardPoints } from "../gameActivity/totalCardPoints";
import { getUserInTable } from "../gameRedisOperations/userInTable";

interface TurnDelayInterface {
    tableId: string,
    currentTurn: number
};

const turnDelayExecute = async (data: TurnDelayInterface) => {

    const tableLock = await applyTableLock("turnDelayExecute", data?.tableId, 2);

    try {

        logger.log("turnDelayExecute", { data });

        const tableData = await getTable(data?.tableId);

        if (tableData.currentTurn !== data.currentTurn) { throw new Error("Current Turn Mismatch !!!"); };

        if (tableData.isTableLock) { await setTable(tableData.tableId, { ...tableData, isTableLock: false, /* isRoundTimer: false, */ isRoundStart: true }); };

        for (let i = 0; i < tableData.users.length; i++) {

            if (tableData.users[i].isLeave) { continue; };

            const userInTableData = await getUserInTable(tableData.tableId, tableData.users[i].userId);

            await totalCardPoints(userInTableData.cards, userInTableData.socketId);

        };

        const isWinning = config.gamePlay.AUTO_WIN ? await checkAutoWin(tableData) : false;

        if (isWinning) {

            await win(tableData.tableId, CONSTANTS.WIN_TYPES.AUTO_WIN);

        } else {

            await turnAdd(data?.tableId, data?.currentTurn);

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.TURN_INFO, { roomId: data?.tableId, data: { currentTurn: data?.currentTurn, turnTimer: config.gamePlay.USER_TURN_TIMER, totalTimer: config.gamePlay.USER_TURN_TIMER, isKnockButton: false } });

        };

    } catch (error: any) {

        logger.errorLog("turnDelayExecute Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("turnDelayExecute", tableLock); };

    };
};

export { turnDelayExecute };