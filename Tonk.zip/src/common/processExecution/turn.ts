import { config } from "../../config";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { eventEmitter } from "../../connection/emitter";
import { changeTurn } from "../gameActivity/changeTurn";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";
import { removeUserFromTable } from "../gameActivity/removeUserFromTable";
import { getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";
import { getUser } from "../gameRedisOperations/user";
import { io } from "../../connection/socket";
import { leaveRoom } from "../socketOperations/leaveRoom";

interface TurnInterface {
    tableId: string,
    currentTurn: number
};

const turnExecute = async (data: TurnInterface) => {

    const tableLock = await applyTableLock("turnExecute", data?.tableId, 2);

    try {

        logger.log("turnExecute", { data });

        const tableData = await getTable(data?.tableId);

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (tableData.currentTurn !== data.currentTurn) { throw new Error("Current Turn Mismatch !!!"); };

        const turnUser = tableData.users.find(e => e.seatIndex === tableData.currentTurn);

        if (!turnUser) { throw new Error("Missing Turn User !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, turnUser.userId);

        if ((userInTableData.turnMiss + 1) === config.gamePlay.TURN_MISS_COUNT) {

            const userSocket = io.sockets.sockets.get(userInTableData.socketId);

            if (userSocket) { await leaveRoom(userSocket, tableData.tableId); };

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: userInTableData.socketId, data: { message: `You have left the previous game before game start. Please exit and join again !!!` } });

            await removeUserFromTable(userInTableData.socketId, tableData.tableId, userInTableData.userId, CONSTANTS.COMMON.TURN_MISSED);

        } else {

            const card = (userInTableData.isHit || userInTableData.isSpread)
                ? (userInTableData.cards.sort((a, b) => Number(b.split("-")[1]) - Number(a.split("-")[1])).find(e => e !== "") ?? userInTableData.lastPickCard)
                : userInTableData.lastPickCard;

            await setTable(tableData.tableId, { ...tableData, openCards: userInTableData.lastPickCard ? [card, ...tableData.openCards] : tableData.openCards });

            await setUserInTable(tableData.tableId, turnUser.userId, { ...userInTableData, turnMiss: userInTableData.turnMiss + 1, cards: userInTableData.cards.filter(e => e !== card) });

            if (userInTableData.lastPickCard) {

                eventEmitter.emit(CONSTANTS.EVENTS_NAME.THROW_CARD, { roomId: tableData.tableId, data: { card, seatIndex: tableData.currentTurn } });

            };

            if (userInTableData.lastPickCard && userInTableData.cards.filter(e => e !== card).length) {

                eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: userInTableData.socketId, data: { message: "Please Throw One Card To Pile !!!" } });

            };

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.TURN_MISSED, { roomId: tableData.tableId, data: { seatIndex: tableData.currentTurn, turnMiss: userInTableData.turnMiss + 1 } });

            await changeTurn(tableData.tableId);

        };

    } catch (error: any) {

        logger.errorLog("turnExecute Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("turnExecute", tableLock); };

    };
};

export { turnExecute };