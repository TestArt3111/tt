import { logger } from "../../logger/logger";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";

interface CardDelayInterface {
    tableId: string,
};

const cardDelayExecute = async (data: CardDelayInterface) => {

    const tableLock = await applyTableLock("cardDelayExecute", data?.tableId, 2);

    try {

        logger.log("cardDelayExecute", { data });

        const tableData = await getTable(data?.tableId);

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        if (!tableData.cardDelay) { throw new Error("Card Delay Is Already Disabled !!!"); };

        await setTable(tableData.tableId, { ...tableData, cardDelay: false });

    } catch (error: any) {

        logger.errorLog("cardDelayExecute Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("cardDelayExecute", tableLock); };

    };
};

export { cardDelayExecute };