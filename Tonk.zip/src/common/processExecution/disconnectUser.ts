import { CONSTANTS } from "../../constants";
import { io } from "../../connection/socket";
import { logger } from "../../logger/logger";
import { getUser } from "../gameRedisOperations/user";
import { getTable } from "../gameRedisOperations/table";
import { applyTableLock, removeTableLock } from "../locks/table";
import { removeUserFromTable } from "../gameActivity/removeUserFromTable";
import { applyMatchMakingLock, removeMatchMakingLock } from "../locks/matchMaking";

interface DisconnectUserInterface {
    userId: string,
    tableId: string,
    bootValue: number
};

const disconnectUserExecute = async (data: DisconnectUserInterface) => {

    const matchMakingLock = await applyMatchMakingLock("disconnectUserExecute", data?.bootValue, 2);

    const tableLock = await applyTableLock("disconnectUserExecute", data?.tableId, 2);

    try {

        logger.log("disconnectUserExecute", { data });

        if (data?.userId === undefined || data?.tableId === undefined || data?.bootValue === undefined) { throw new Error("Needed Data Not Available !!!"); };

        const userData = await getUser(data?.userId);

        if (userData.tableId !== data?.tableId) { throw new Error("User TableId And Bull Timer TableId Is Different !!!"); };

        if (io.sockets.sockets.get(userData.socketId)) { throw new Error("User Socket Is Connected !!!"); };

        if (!userData?.tableId || userData?.tableId === CONSTANTS.COMMON.DISCONNECTED || userData?.tableId === CONSTANTS.COMMON.TURN_MISSED) { throw new Error("User Is Not In Playing State !!!"); };

        const tableData = await getTable(data?.tableId);

        if (!tableData.users.find(e => e.userId === data?.userId)) { throw new Error("User Not Available In This Table !!!"); };

        await removeUserFromTable("", tableData.tableId, userData.userId, CONSTANTS.COMMON.DISCONNECTED);

    } catch (error: any) {

        logger.errorLog("disconnectUserExecute Error : ", error);

    } finally {

        if (matchMakingLock) { await removeMatchMakingLock("disconnectUserExecute", matchMakingLock); };

        if (tableLock) { await removeTableLock("disconnectUserExecute", tableLock); };

    };
};

export { disconnectUserExecute };