import { config } from "../../config";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { eventEmitter } from "../../connection/emitter";
import { startNextRound } from "../gameActivity/startNextRound";
import { applyTableLock, removeTableLock } from "../locks/table";
import { deleteWinning, getWinning } from "../gameRedisOperations/winning";
import { applyMatchMakingLock, removeMatchMakingLock } from "../locks/matchMaking";

interface WinDelayInterface {
    tableId: string,
    bootValue: number
};

const winDelayExecute = async (data: WinDelayInterface) => {

    const matchMakingLock = await applyMatchMakingLock("winDelayExecute", data?.bootValue, 2);

    const tableLock = await applyTableLock("winDelayExecute", data?.tableId, 2);

    try {

        logger.log("winDelayExecute", { data });

        const winningData = await getWinning(data?.tableId);

        await deleteWinning(data?.tableId);

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.WINNING, { roomId: data?.tableId, data: { timer: config.gamePlay.GAME_START_TIMER, ...winningData } });

        await startNextRound(data?.tableId);

    } catch (error: any) {

        logger.errorLog("winDelayExecute Error : ", error);

    } finally {

        if (matchMakingLock) { await removeMatchMakingLock("winDelayExecute", matchMakingLock); };

        if (tableLock) { await removeTableLock("winDelayExecute", tableLock); };

    };
};

export { winDelayExecute };