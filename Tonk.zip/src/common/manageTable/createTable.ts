import { Socket } from "socket.io";

import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { dummyTable } from "../dummyData/table";
import { setUser } from "../gameRedisOperations/user";
import { UserInterface } from "../../interfaces/user";
import { joinRoom } from "../socketOperations/joinRoom";
import { eventEmitter } from "../../connection/emitter";
import { setTable } from "../gameRedisOperations/table";
import { dummyTableUser } from "../dummyData/tableUser";
import { dummyUserInTable } from "../dummyData/userInTable";
import { setEmptyTable } from "../gameRedisOperations/emptyTable";
import { UserInTableInterface } from "../../interfaces/userInTable";
import { setUserInTable } from "../gameRedisOperations/userInTable";
import { TableInterface, TableUsersInterface } from "../../interfaces/table";
import { Gamerunning } from "../../api/models/addGameRunning";

const createTable = async (socket: Socket, user: UserInterface) => {

    try {

        logger.log("createTable", { user });

        const table: TableInterface = await dummyTable(user);

        const tableUser: TableUsersInterface = await dummyTableUser(user, 0);

        const userInTable: UserInTableInterface = await dummyUserInTable(user.userId, table.tableId, 0, socket.id);

        table.users.push(tableUser);

        await Promise.all([

            joinRoom(socket, table?.tableId),

            setTable(table.tableId, table),

            setEmptyTable(user.lobbyId, table.tableId),

            setUserInTable(table.tableId, user.userId, userInTable),

            setUser(user.userId, { ...user, tableId: table.tableId })

        ]);

        await Gamerunning.create({ userId: user.userId, tableId: table.tableId, lobbyId: user.lobbyId });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.JOIN_TABLE, { roomId: table.tableId, data: table });

        socket.handshake.auth.tableId = table.tableId;
        socket.handshake.auth.seatIndex = userInTable.seatIndex;

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("createTable Error : ", error);

    };
};

export { createTable };