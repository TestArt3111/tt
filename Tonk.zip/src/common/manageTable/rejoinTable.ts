import { Socket } from "socket.io";

import { config } from "../../config";
import { findTable } from "./findTable";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { turnGet } from "../../bull/get/turn";
import { UserInterface } from "../../interfaces/user";
import { getTable } from "../gameRedisOperations/table";
import { joinRoom } from "../socketOperations/joinRoom";
import { eventEmitter } from "../../connection/emitter";
import { gameStartGet } from "../../bull/get/gameStart";
import { TableInterface } from "../../interfaces/table";
import { remainingBullTime } from "../remainingBullTime";
import { applyTableLock, removeTableLock } from "../locks/table";
import { totalCardPoints } from "../gameActivity/totalCardPoints";
import { getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";

const rejoinTable = async (socket: Socket, user: UserInterface) => {

    const tableLock = await applyTableLock("rejoinTable", user.tableId, 2);

    try {

        logger.log("rejoinTable", { user });

        const tableData: TableInterface = await getTable(user.tableId);

        if (!tableData?.users?.find(e => e?.userId === user?.userId)) { return false; };

        const userInTableData = await getUserInTable(user.tableId, user.userId);

        await joinRoom(socket, tableData?.tableId);

        const turnTimer = tableData.isWinning ? 0 : await remainingBullTime(await turnGet(tableData.tableId), 0);

        const gameTimer = tableData.isWinning ? 0 : await remainingBullTime(await gameStartGet(tableData.tableId), 0);

        const usersDetails = await Promise.all(tableData.users.map(async (tableUser) => {

            const userInTable = tableUser.userId === user.userId ? userInTableData : await getUserInTable(tableData.tableId, tableUser.userId);

            return {

                hands: userInTable.hands,
                knockLock: userInTable.knockLock,
                cardsLength: userInTable.cards.length,
                lastPickCard: userInTable.lastPickCard ? true : false,
                isMyTurn: userInTable.seatIndex === tableData.currentTurn,
                cards: tableUser.userId === user.userId ? userInTable.cards : [],
                isKnockButton: userInTable.seatIndex === tableData.currentTurn && userInTable.knockLock === 0,
                score: tableUser.userId === user.userId ? await totalCardPoints(userInTableData.cards, "") : 0,

            };

        }));

        socket.handshake.auth.tableId = tableData.tableId;
        socket.handshake.auth.bootValue = tableData.bootValue;
        socket.handshake.auth.seatIndex = userInTableData.seatIndex;

        await setUserInTable(tableData.tableId, user.userId, { ...userInTableData, socketId: socket.id });

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.REJOIN, {
            socketId: socket.id,
            data: {
                gameTimer,
                turnTimer,
                totalTimer: config.gamePlay.USER_TURN_TIMER,
                table: {
                    ...tableData,
                    closeCards: tableData.closeCards.length,
                    openCards: tableData.openCards.slice(0, 2),
                    users: tableData.users.map((e, i) => ({ ...e, ...usersDetails[i] }))
                }
            }
        });

        return true;

    } catch (error: any) {

        logger.errorLog("rejoinTable Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("rejoinTable", tableLock); };

    };
};

export { rejoinTable };