import { Socket } from "socket.io";

import { joinTable } from "./joinTable";
import { createTable } from "./createTable";
import { logger } from "../../logger/logger";
import { UserInterface } from "../../interfaces/user";
import { getTable } from "../gameRedisOperations/table";
import { getEmptyTable } from "../gameRedisOperations/emptyTable";
import { eventEmitter } from "../../connection/emitter";
import { CONSTANTS } from "../../constants";
import { TournamentModel } from "../../api/models/lobby";
import { MaintenanceModel } from "../../api/models/maintenance";
import { gameMaintenance } from "../../api/helper/maintenance";
import { User } from "../../api/models/user";

const findTable = async (socket: Socket, user: UserInterface) => {

    try {

        logger.log("findTable", { user });

        // const userData = await User.findOne({ deviceId: user.userId });

        // if (userData && userData.isBlock) { return eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: socket.id, data: { message: "User Block !!!" } }); };

        const lobby = await TournamentModel.findOne({ _id: user.lobbyId, isActive: true });

        if (!lobby) { throw new Error("Lobby Not Found !!!"); };

        if (lobby.entryfee !== user.bootValue) { throw new Error("Boot Value Miss Match"); };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        const message = isMaintenance ? (getMaintenance?.description ? getMaintenance?.description : "Maintenance !!!") : "You Don't Have Enough Chips !!!";

        if (user && user?.chips < (user.bootValue * 2) || isMaintenance) { return eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: socket.id, data: { message } }); };

        const emptyTables = await getEmptyTable(user.lobbyId);

        if (emptyTables?.length) {

            for (let i = 0; i < emptyTables.length; i++) {

                const tableData = await getTable(emptyTables[i]).catch((error) => { logger.errorLog("findTable emptyTables Error : ", error); });

                if (!tableData || tableData.isTableLock || tableData.isRoundStart || tableData.isWinning) { continue; };

                const tableMatch = await joinTable(socket, user, tableData.tableId);

                if (tableMatch) { return; };

            };

            await createTable(socket, user);

        } else { await createTable(socket, user); };

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("findTable Error : ", error);

    };
};

export { findTable };