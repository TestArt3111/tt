import { Socket } from "socket.io";

import { config } from "../../config";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { UserInterface } from "../../interfaces/user";
import { setUser } from "../gameRedisOperations/user";
import { joinRoom } from "../socketOperations/joinRoom";
import { eventEmitter } from "../../connection/emitter";
import { gameStartAdd } from "../../bull/add/gameStart";
import { dummyTableUser } from "../dummyData/tableUser";
import { tableLockAdd } from "../../bull/add/tableLock";
import { gameStartGet } from "../../bull/get/gameStart";
import { remainingBullTime } from "../remainingBullTime";
import { dummyUserInTable } from "../dummyData/userInTable";
import { TableUsersInterface } from "../../interfaces/table";
import { applyTableLock, removeTableLock } from "../locks/table";
import { getTable, setTable } from "../gameRedisOperations/table";
import { UserInTableInterface } from "../../interfaces/userInTable";
import { setUserInTable } from "../gameRedisOperations/userInTable";
import { deleteEmptyTable } from "../gameRedisOperations/emptyTable";
import { Gamerunning } from "../../api/models/addGameRunning";

const joinTable = async (socket: Socket, user: UserInterface, tableId?: string) => {

    const tableLock = await applyTableLock("joinTable", tableId ?? "", 2);

    try {

        logger.log("joinTable", { user, tableId });

        if (!tableId) { throw new Error("Table Id Not Found !!!"); };

        const tableData = await getTable(tableId);

        const availableSeat = Array.from({ length: config.gamePlay.MAX_USERS }, (_, index) => tableData?.users?.findIndex(e => e?.seatIndex === index) === -1 ? index : -1).find(e => e >= 0);

        if (availableSeat === undefined) { return false; };

        const tableUser: TableUsersInterface = await dummyTableUser(user, availableSeat);

        const userInTable: UserInTableInterface = await dummyUserInTable(user.userId, tableId, availableSeat, socket.id);

        tableData.users = [...tableData.users, tableUser].sort((first: TableUsersInterface, second: TableUsersInterface) => first.seatIndex - second.seatIndex);

        socket.handshake.auth.tableId = tableId;
        socket.handshake.auth.seatIndex = userInTable.seatIndex;

        await Promise.all([

            joinRoom(socket, tableId),

            setUser(user.userId, { ...user, tableId }),

            setUserInTable(tableId, user.userId, userInTable),

            setTable(tableId, { ...tableData, isGameStart: true, isRoundTimer: true })

        ]);

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.JOIN_TABLE, { roomId: tableId, data: tableData });

        if (tableData.users.length === config.gamePlay.MAX_USERS) { await deleteEmptyTable(user.lobbyId, tableId); };

        if (!tableData.isGameStart) {

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.GAME_START, { roomId: tableId, data: { timer: config.gamePlay.GAME_START_TIMER } });

            await Promise.all([gameStartAdd(tableId), tableLockAdd(tableId)]);

        } else {

            const timeDiff = await remainingBullTime(await gameStartGet(tableId), 0);

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.GAME_START, { roomId: socket.id, data: { timer: timeDiff } });

        };

        await Gamerunning.create({ userId: user.userId, tableId: tableData.tableId, lobbyId: user.lobbyId });

        return true;

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId: socket.id, data: { message: error?.message } });

        logger.errorLog("joinTable Error : ", error);

    } finally {

        if (tableLock) { await removeTableLock("joinTable", tableLock); };

    };
};

export { joinTable };