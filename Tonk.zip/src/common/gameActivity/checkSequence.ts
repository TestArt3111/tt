import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";

const checkSequence = async (arr: Array<string>) => {

    try {

        logger.log("checkSequence", { arr });

        const isValidSequence = async (arr: Array<number>) => (arr.every((value, index) => index === 0 || value === arr[index - 1] + 1));

        let isLowSequence = false, isHighSequence = false;

        if (arr.length < 3) { return { isLowSequence, isHighSequence }; };

        if (!arr.every(e => CONSTANTS.CARDS.includes(e))) { return { isLowSequence, isHighSequence }; };

        const cardsColor = [...new Set(arr.map(e => e.split("-")[0]))];

        const cardsNumber = [...new Set(arr.map(e => Number(e.split("-")[1])))].sort((a, b) => a - b);

        if (cardsColor.length !== 1 || cardsNumber.length !== arr.length) { return { isLowSequence, isHighSequence }; };

        const changeAce = cardsNumber.map(e => (e === 1) ? 14 : e).sort((a, b) => a - b);

        isLowSequence = await isValidSequence(cardsNumber);

        isHighSequence = isLowSequence ? false : await isValidSequence(changeAce);

        return { isLowSequence, isHighSequence };

    } catch (error: any) {
        logger.errorLog("checkSequence Error : ", error);
    };
};

export { checkSequence };