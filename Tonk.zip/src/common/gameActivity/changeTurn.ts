import { win } from "./win";
import { config } from "../../config";
import { knockLock } from "./knockLock";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { turnAdd } from "../../bull/add/turn";
import { totalCardPoints } from "./totalCardPoints";
import { clockWiseTurn } from "../nextTurn/clockWise";
import { eventEmitter } from "../../connection/emitter";
import { getTable, setTable } from "../gameRedisOperations/table";
import { getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";

const changeTurn = async (tableId: string) => {

    try {

        logger.log("changeTurn", { tableId });

        const tableData = await getTable(tableId);

        if (!tableData.isRoundStart) { throw new Error("Round Not Started !!!"); };

        const turnUser = tableData.users.find(e => e.seatIndex === tableData.currentTurn);

        if (!turnUser) { throw new Error("Missing Turn User !!!"); };

        const userInTableData = await getUserInTable(tableData.tableId, turnUser.userId);

        if (!turnUser.isLeave) { await totalCardPoints(userInTableData.cards, userInTableData.socketId); };

        if (!userInTableData.cards.length || !tableData.closeCards.length) { // ^ Win

            await win(tableId, !userInTableData.cards.length ? CONSTANTS.WIN_TYPES.TONK : "");

        } else {

            const nextTurn = await clockWiseTurn(tableData);

            if (nextTurn === undefined) { throw new Error("Failed To Find Next User Turn !!!"); };

            await setTable(tableData.tableId, { ...tableData, currentTurn: nextTurn });

            await setUserInTable(tableData.tableId, turnUser.userId, {
                ...userInTableData,
                isHit: false,
                isSpread: false,
                lastPickCard: "",
                settledCard: 0,
                knockLock: (userInTableData.isHit || userInTableData.isSpread) ? userInTableData.knockLock : Math.max(userInTableData.knockLock - 1, 0)
            });

            await knockLock(tableData.tableId, tableData.users);

            await turnAdd(tableData.tableId, nextTurn);

            // ^ For Knock Button

            const nextTurnUserInTableData = await getUserInTable(tableData.tableId, tableData.users.find(user => user.seatIndex === nextTurn)?.userId ?? "");

            let isKnockButton = (nextTurnUserInTableData && nextTurnUserInTableData.knockLock === 0);

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.TURN_INFO, { roomId: tableData.tableId, data: { currentTurn: nextTurn, turnTimer: config.gamePlay.USER_TURN_TIMER, totalTimer: config.gamePlay.USER_TURN_TIMER, isKnockButton } });

        };

    } catch (error: any) {
        logger.errorLog("changeTurn Error : ", error);
    };
};

export { changeTurn };