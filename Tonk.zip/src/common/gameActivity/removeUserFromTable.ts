import { win } from "./win";
import { changeTurn } from "./changeTurn";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { io } from "../../connection/socket";
import { eventEmitter } from "../../connection/emitter";
import { leaveRoom } from "../socketOperations/leaveRoom";
import { gameStartRemove } from "../../bull/remove/gameStart";
import { tableLockRemove } from "../../bull/remove/tableLock";
import { getUser, setUser } from "../gameRedisOperations/user";
import { deleteTable, getTable, setTable } from "../gameRedisOperations/table";
import { deleteEmptyTable, getEmptyTable, setEmptyTable } from "../gameRedisOperations/emptyTable";
import { deleteUserInTable, getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";
import { Gamerunning } from "../../api/models/addGameRunning";

const removeUserFromTable = async (socketId: string, tableId: string, userId: string, leaveReason: string) => {

    try {

        logger.log("removeUserFromTable", { tableId, userId });

        const userData = await getUser(userId);

        const tableData = await getTable(tableId);

        const userInTableData = await getUserInTable(tableId, userId);

        const leaveUser = tableData.users.find(e => e.userId === userId);

        if (!leaveUser || leaveUser?.isLeave) { throw new Error("User Not Available In This Table !!!"); };

        if (tableData.isTableLock || tableData.isWinning) { throw new Error("Currently You Can't Able To Leave Game !!!"); };

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.LEAVE_TABLE, { roomId: tableId, data: { userId, tableId } });

        const userSocket = io.sockets.sockets.get(userData.socketId);

        if (userSocket) { await leaveRoom(userSocket, tableId); };

        await Gamerunning.deleteOne({ userId: userData.userId });

        if (tableData.isRoundTimer || !tableData.isGameStart) {

            const users = tableData.users.filter(e => e.userId !== userId);

            await deleteUserInTable(tableId, userId);

            await setUser(userId, { ...userData, tableId: leaveReason });

            if (!users.length) {

                await deleteTable(tableId);

                await deleteEmptyTable(userData.lobbyId, tableId);

                return;

            };

            if (users.length === 1) {

                await gameStartRemove(tableId);

                await tableLockRemove(tableId);

                await setTable(tableId, { ...tableData, users, isGameStart: false, isRoundTimer: false });

                eventEmitter.emit(CONSTANTS.EVENTS_NAME.WAITING, { roomId: tableId, data: {} });

            } else { await setTable(tableId, { ...tableData, users }); };

            const emptyTables = await getEmptyTable(userData.lobbyId);

            if (!emptyTables?.includes(tableId)) { await setEmptyTable(userData.lobbyId, tableId); };

        } else {

            const users = tableData.users.map(e => e.userId === userId ? { ...e, isLeave: true } : e);

            await setUser(userId, { ...userData, tableId: leaveReason });

            if (users.filter(e => !e.isLeave).length === 1) {

                await setTable(tableId, { ...tableData, users });

                await win(tableId, "");

                return;

            };

            if (tableData.currentTurn === leaveUser?.seatIndex) {

                if (userInTableData.lastPickCard) {

                    const card = (userInTableData.isHit || userInTableData.isSpread)
                        ? (userInTableData.cards.sort((a, b) => Number(b.split("-")[1]) - Number(a.split("-")[1])).find(e => e !== "") ?? userInTableData.lastPickCard)
                        : userInTableData.lastPickCard;

                    await setTable(tableData.tableId, { ...tableData, users, openCards: userInTableData.lastPickCard ? [card, ...tableData.openCards] : tableData.openCards });

                    await setUserInTable(tableData.tableId, userId, { ...userInTableData, hands: [], cards: userInTableData.cards.filter(e => e !== card) });

                    eventEmitter.emit(CONSTANTS.EVENTS_NAME.THROW_CARD, { roomId: tableData.tableId, data: { card, seatIndex: tableData.currentTurn } });

                } else {

                    await setTable(tableId, { ...tableData, users });

                    await setUserInTable(tableData.tableId, userId, { ...userInTableData, hands: [] });

                };

                await changeTurn(tableId);

            } else {

                await setTable(tableId, { ...tableData, users });

                await setUserInTable(tableData.tableId, userId, { ...userInTableData, hands: [] });

            };

            const emptyTables = await getEmptyTable(userData.lobbyId);

            if (!emptyTables?.includes(tableId)) { await setEmptyTable(userData.lobbyId, tableId); };

        };

    } catch (error: any) {

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ERROR_POPUP, { socketId, data: { message: error?.message } });

        logger.errorLog("removeUserFromTable Error : ", error);

    };
};

export { removeUserFromTable };