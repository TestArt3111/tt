import { config } from "../../config";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { eventEmitter } from "../../connection/emitter";

const totalCardPoints = async (cards: Array<string>, socketId: string) => {

    try {

        logger.log("totalCardPoints", { cards });

        const points = cards.reduce((last: any, current: any) => {

            if (Number(current.split("-")[1]) === 11) { return last + config.gamePlay.JACK_POINT }
            else if (Number(current.split("-")[1]) === 12) { return last + config.gamePlay.QUEEN_POINT }
            else if (Number(current.split("-")[1]) === 13) { return last + config.gamePlay.KING_POINT }
            else { return last + Number(current.split("-")[1]) };

        }, 0);

        if (socketId) { eventEmitter.emit(CONSTANTS.EVENTS_NAME.CARD_POINTS, { socketId, data: { points } }); };

        return points;

    } catch (error: any) {
        logger.errorLog("totalCardPoints Error : ", error);
    };
};

export { totalCardPoints };