import { config } from "../../config";
import { logger } from "../../logger/logger";

const cardsPoint = async (cards: Array<string>) => {

    try {

        logger.log("cardsPoint", { cards });

        return cards.reduce((last: any, current: any) => {

            if (Number(current.split("-")[1]) === 11) { return [...last, config.gamePlay.JACK_POINT] }
            else if (Number(current.split("-")[1]) === 12) { return [...last, config.gamePlay.QUEEN_POINT] }
            else if (Number(current.split("-")[1]) === 13) { return [...last, config.gamePlay.KING_POINT] }
            else { return [...last, Number(current.split("-")[1])] };

        }, []);

    } catch (error: any) {
        logger.errorLog("cardsPoint Error : ", error);
    };
};

export { cardsPoint };