import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";

const checkSet = async (arr: Array<string>) => {

    try {

        logger.log("checkSet", { arr });

        if (arr.length < 3) { return false };

        if (!arr.every(e => CONSTANTS.CARDS.includes(e))) { return false };

        const cardsColor = [...new Set(arr.map(e => e.split("-")[0]))];

        const cardsNumber = [...new Set(arr.map(e => e.split("-")[1]))];

        return (cardsColor.length === arr.length && cardsNumber.length === 1) ? true : false;

    } catch (error: any) {
        logger.errorLog("checkSet Error : ", error);
    };
};

export { checkSet };