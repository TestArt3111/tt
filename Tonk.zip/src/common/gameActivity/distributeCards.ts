import { config } from "./../../config";
import { knockLock } from "./knockLock";
import { logger } from "../../logger/logger";
import { CONSTANTS } from "./../../constants";
import { shuffleArray } from "../shuffleArray";
import { eventEmitter } from "../../connection/emitter";
import { turnDelayAdd } from "../../bull/add/turnDelay";
import { getTable, setTable } from "../gameRedisOperations/table";
import { getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";

const distributeCards = async (tableId: string) => {

    try {

        logger.log("distributeCards", { tableId });

        const tableData = await getTable(tableId);

        if (!tableData.isRoundTimer) { throw new Error("Round Timer Not Started !!!"); };

        const cards = await shuffleArray([...CONSTANTS.CARDS]); // * Use This

        for (let i = 0; i < tableData.users.length; i++) {

            if (tableData.users[i].isLeave) { continue; };

            const userInTableData = await getUserInTable(tableId, tableData.users[i].userId);

            const userCards = cards.splice(0, config.gamePlay.DISTRIBUTE_CARDS_LIMIT);

            await setUserInTable(tableId, tableData.users[i].userId, { ...userInTableData, cards: userCards });

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.MY_CARDS, { socketId: userInTableData.socketId, data: { cards: userCards } });

        };

        // await setTable(tableId, { ...tableData, closeCards: cards }); 1
        await setTable(tableId, { ...tableData, closeCards: cards, /* isRoundStart: true, */ isRoundTimer: false });
        // await setTable(tableId, { ...tableData, closeCards: cards });

        await knockLock(tableId, tableData.users);

        await turnDelayAdd(tableData.tableId, tableData.currentTurn, 3);

    } catch (error: any) {
        logger.errorLog("distributeCards Error : ", error);
    };
};

export { distributeCards };