import { config } from "../../config";
import { CONSTANTS } from "../../constants";
import { io } from "../../connection/socket";
import { logger } from "../../logger/logger";
import { turnRemove } from "../../bull/remove/turn";
import { eventEmitter } from "../../connection/emitter";
import { gameStartAdd } from "../../bull/add/gameStart";
import { tableLockAdd } from "../../bull/add/tableLock";
import { leaveRoom } from "../socketOperations/leaveRoom";
import { dummyUserInTable } from "../dummyData/userInTable";
import { winDelayRemove } from "../../bull/remove/winDelay";
import { gameStartRemove } from "../../bull/remove/gameStart";
import { tableLockRemove } from "../../bull/remove/tableLock";
import { turnDelayRemove } from "../../bull/remove/turnDelay";
import { cardDelayRemove } from "../../bull/remove/cardDelay";
import { getUser, setUser } from "../gameRedisOperations/user";
import { UserInTableInterface } from "../../interfaces/userInTable";
import { deleteTable, getTable, setTable } from "../gameRedisOperations/table";
import { deleteEmptyTable, getEmptyTable, setEmptyTable } from "../gameRedisOperations/emptyTable";
import { deleteUserInTable, getUserInTable, setUserInTable } from "../gameRedisOperations/userInTable";
import { Gamerunning } from "../../api/models/addGameRunning";
import { MaintenanceModel } from "../../api/models/maintenance";
import { gameMaintenance } from "../../api/helper/maintenance";

const startNextRound = async (tableId: string) => {

    try {

        logger.log("startNextRound", { tableId });

        const tableData = await getTable(tableId);

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        for (let i = 0; i < tableData.users.length; i++) {

            const userData = await getUser(tableData.users[i].userId);

            eventEmitter.emit(CONSTANTS.EVENTS_NAME.SELF_BALANCE, { socketId: userData.socketId, data: { userId: userData.userId, chips: userData.chips } });

            if (tableData.users[i].isLeave) {

                await deleteUserInTable(tableData.tableId, tableData.users[i].userId);

                continue;

            };

            const userSocket = io.sockets.sockets.get(userData.socketId);

            if (!userSocket) {

                tableData.users[i].isLeave = true;

                await deleteUserInTable(tableData.tableId, tableData.users[i].userId);

                await Gamerunning.deleteOne({ userId: userData.userId });

                await setUser(userData.userId, { ...userData, tableId: CONSTANTS.COMMON.DISCONNECTED });

                continue;

            };

            if (userData.chips < (tableData.bootValue * 2) || isMaintenance) {

                tableData.users[i].isLeave = true;

                await leaveRoom(userSocket, tableId);

                await deleteUserInTable(tableData.tableId, tableData.users[i].userId);

                await Gamerunning.deleteOne({ userId: userData.userId });

                await setUser(userData.userId, { ...userData, tableId: "" });

                const message = isMaintenance ? (getMaintenance?.description ? getMaintenance?.description : "Maintenance !!!") : "You Don't Have Enough Chips !!!";

                eventEmitter.emit(CONSTANTS.EVENTS_NAME.ALERT, { socketId: userData.socketId, data: { message } });

                continue;

            };

            const userInTableData = await getUserInTable(tableId, tableData.users[i].userId);

            const userInTable: UserInTableInterface = await dummyUserInTable(userInTableData.userId, tableData.tableId, userInTableData.seatIndex, userData.socketId);

            await setUserInTable(tableId, tableData.users[i].userId, userInTable);

        };

        await Promise.all([turnRemove(tableId), winDelayRemove(tableId), gameStartRemove(tableId), cardDelayRemove(tableId), tableLockRemove(tableId), turnDelayRemove(tableId)]);

        const users = tableData.users.filter(e => !e.isLeave);

        if (!users.length) {

            await deleteTable(tableData.tableId);

            await deleteEmptyTable(tableData.lobbyId, tableData.tableId);

            return;

        };

        if (users.length !== config.gamePlay.MAX_USERS) {

            const emptyTables = await getEmptyTable(tableData.lobbyId);

            if (!emptyTables?.includes(tableId)) { await setEmptyTable(tableData.lobbyId, tableId); };

        };

        await setTable(tableData.tableId, {
            ...tableData,
            reward: 0,
            currentTurn: -1,
            users: users,
            openCards: [],
            closeCards: [],
            isWinning: false,
            cardDelay: false,
            isRoundTimer: true,
            isGameStart: users.length !== 1,
            roundNum: tableData.roundNum + 1,
        });

        if (users.length !== 1) { await Promise.all([gameStartAdd(tableId), tableLockAdd(tableId)]); };

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.ACTIVE_PLAYERS, { roomId: tableData.tableId, data: { isWaiting: users.length === 1 ? true : false, roundNum: (tableData.roundNum + 1), users } });

    } catch (error: any) {
        logger.errorLog("startNextRound Error : ", error);
    };
};

export { startNextRound };