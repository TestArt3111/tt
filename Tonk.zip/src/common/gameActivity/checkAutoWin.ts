import { config } from "../../config";
import { logger } from "../../logger/logger";
import { totalCardPoints } from "./totalCardPoints";
import { TableInterface } from "../../interfaces/table";
import { getUserInTable } from "../gameRedisOperations/userInTable";

const checkAutoWin = async (tableData: TableInterface) => {

    try {

        logger.log("checkAutoWin", { tableData });

        for (let i = 0; i < tableData.users.length; i++) {

            const userInTableData = await getUserInTable(tableData.tableId, tableData.users[i].userId);

            const totalPoints = await totalCardPoints(userInTableData.cards, "");

            if (totalPoints === undefined) { throw new Error("Failed To Calculate Cards Point !!!"); };

            if (config.gamePlay.AUTO_WIN_SCORES.includes(totalPoints)) { return true; };

        };

        return false;

    } catch (error: any) {
        logger.errorLog("checkAutoWin Error : ", error);
    };
};

export { checkAutoWin };