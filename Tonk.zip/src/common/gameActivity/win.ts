import { config } from "../../config";
import { cardsPoint } from "./cardsPoint";
import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { totalCardPoints } from "./totalCardPoints";
import { winDelayAdd } from "../../bull/add/winDelay";
import { eventEmitter } from "../../connection/emitter";
import { setWinning } from "../gameRedisOperations/winning";
import { WinArrayInterface } from "../../interfaces/winning";
import { getUser, setUser } from "../gameRedisOperations/user";
import { getTable, setTable } from "../gameRedisOperations/table";
import { getUserInTable } from "../gameRedisOperations/userInTable";
import { User } from "../../api/models/user";

const win = async (tableId: string, winType: string) => {

    try {

        logger.log("win", { tableId, winType });

        const tableData = await getTable(tableId);

        let winArr: Array<WinArrayInterface> = [], lowestScore = -1, leftUsers: Array<WinArrayInterface> = [], winUsers: Array<string> = [], isTonkOutPenalty = false, isDraw = false;

        for (let i = 0; i < tableData.users.length; i++) {

            const userInTableData = await getUserInTable(tableId, tableData.users[i].userId);

            const [totalPoints, cardWisePoints] = await Promise.all([totalCardPoints(userInTableData.cards, ""), cardsPoint(userInTableData.cards)]);

            if (totalPoints === undefined || cardWisePoints === undefined) { throw new Error("Failed To Calculate Cards Point !!!"); };

            if (tableData.users[i].isLeave) {

                leftUsers.push({
                    userId: tableData.users[i].userId,
                    userName: tableData.users[i].userName,
                    userProfile: tableData.users[i].userProfile,
                    cards: userInTableData.cards,
                    cardWisePoints,
                    totalPoints,
                    isKnock: false,
                    isLeave: true,
                    isWinner: false,
                    isPenalty: false,
                    amount: 0
                });

            } else {

                if (lowestScore === -1 || lowestScore > totalPoints) { lowestScore = totalPoints; };

                winArr.push({
                    userId: tableData.users[i].userId,
                    userName: tableData.users[i].userName,
                    userProfile: tableData.users[i].userProfile,
                    cards: userInTableData.cards,
                    cardWisePoints,
                    totalPoints,
                    isKnock: userInTableData.isKnock,
                    isLeave: false,
                    isWinner: false,
                    isPenalty: false,
                    amount: 0
                });

            };

        };

        isTonkOutPenalty = (winType === CONSTANTS.WIN_TYPES.TONKS_OUT && config.gamePlay.TONK_OUT_PENALTY);

        winArr.sort((a, b) => a.totalPoints - b.totalPoints);

        if (CONSTANTS.WIN_TYPES.AUTO_WIN === winType) {

            winArr.forEach(e => e.isWinner = config.gamePlay.AUTO_WIN_SCORES.includes(e.totalPoints));

            lowestScore = winArr.find(e => e.isWinner)?.totalPoints ?? -1;

            winArr.forEach(e => e.isWinner = e.totalPoints === lowestScore);

        } else {

            isDraw = winArr.filter((e) => e.totalPoints === lowestScore).length > 1;

            winArr.forEach(e => e.isWinner = (e.totalPoints === lowestScore));

            if (isDraw) { winArr.forEach(e => e.isWinner = (!e.isKnock && e.totalPoints === lowestScore)) };

        };

        isDraw = winArr.filter((e) => e.isWinner).length > 1;

        winArr = [...winArr, ...leftUsers];

        if (config.gamePlay.KNOCK_PENALTY) { winArr.forEach(e => { if (e.isKnock && !e.isWinner) { e.isPenalty = true; } }) };

        if (isTonkOutPenalty) { winArr.forEach(e => { if (!e.isWinner) { e.isPenalty = true } }); };

        const isPenalty = winArr.filter(e => e.isPenalty).length;

        const winnersCount = winArr.filter(e => e.isWinner).length;

        // * Add Watching Here ... For Amount Calculation ...

        const winAmount = (isPenalty || isTonkOutPenalty) ? (((tableData.bootValue * tableData.users.length) + (tableData.bootValue * isPenalty)) / winnersCount) : ((tableData.bootValue * tableData.users.length) / winnersCount);

        winArr = winArr.map(e => e.isWinner ? { ...e, amount: winAmount } : { ...e, amount: -Math.abs(tableData.bootValue) }).map(e => e.isPenalty ? { ...e, amount: e.amount + (-Math.abs(tableData.bootValue)) } : e);

        for (let i = 0; i < winArr.length; i++) {

            const userData = await getUser(winArr[i]?.userId);

            if (winArr[i].isWinner) {

                await setUser(userData.userId, { ...userData, chips: userData.chips + winAmount + tableData.bootValue });

                await User.findOneAndUpdate({ deviceId: userData.userId }, { $inc: { winGames: 1, chips: (winAmount + tableData.bootValue) } });

            };

            if (!winArr[i].isPenalty && !winArr[i].isWinner) {

                await setUser(userData.userId, { ...userData, chips: userData.chips + tableData.bootValue });

                await User.findOneAndUpdate({ deviceId: userData.userId }, { $inc: { loseGames: 1, chips: tableData.bootValue } });

            };

            if (winArr[i].isPenalty) { await User.findOneAndUpdate({ deviceId: userData.userId }, { $inc: { loseGames: 1 } }); }

        };

        await setWinning(tableId, { winType, isDraw, winArr });

        await setTable(tableId, { ...tableData, isWinning: true, isRoundStart: false });

        await winDelayAdd(tableId, tableData.bootValue, 2);

        for (let i = 0; i < winArr.length; i++) { if (winArr[i].isWinner) { winUsers.push(winArr[i].userId) } };

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.WIN_TYPE, { roomId: tableId, data: { winType, winUsers, winAmount } });

    } catch (error: any) {
        logger.errorLog("win Error : ", error);
    };
};

export { win };