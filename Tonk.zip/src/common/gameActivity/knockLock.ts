import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { eventEmitter } from "../../connection/emitter";
import { TableUsersInterface } from "../../interfaces/table";
import { getUserInTable } from "../gameRedisOperations/userInTable";

const knockLock = async (tableId: string, users: Array<TableUsersInterface>) => {

    try {

        logger.log("knockLock", { tableId, users });

        const knockLock = await Promise.all(users.map(async (user) => {

            const userInTableData = await getUserInTable(tableId, user.userId);

            return { userId: userInTableData.userId, seatIndex: userInTableData.seatIndex, knockLock: userInTableData.knockLock };

        }));

        eventEmitter.emit(CONSTANTS.EVENTS_NAME.KNOCK_LOCK, { roomId: tableId, data: { knockLock } });

    } catch (error: any) {
        logger.errorLog("knockLock Error : ", error);
    };
};

export { knockLock };