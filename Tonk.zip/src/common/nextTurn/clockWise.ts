import { logger } from "../../logger/logger";
import { TableInterface } from "../../interfaces/table";
import { config } from "../../config";

const clockWiseTurn = async (tableData: TableInterface) => {

    try {

        logger.log("clockWiseTurn", { tableData });

        let nextTurn = (tableData.currentTurn + 1) % config.gamePlay.MAX_USERS;

        for (let i = 0; i < tableData.users.length; i++) {

            if (tableData.users.find(e => e.seatIndex === nextTurn)?.isLeave === false) { break; };

            nextTurn = (nextTurn + 1) % config.gamePlay.MAX_USERS;

        };

        logger.log("clockWiseTurn Return : ", { nextTurn });

        return nextTurn;

    } catch (error: any) {
        logger.errorLog("clockWiseTurn Error : ", error);
    };
};

export { clockWiseTurn };