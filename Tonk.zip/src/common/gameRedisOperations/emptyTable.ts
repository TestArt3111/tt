import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { addToArray, getArray, removeFromArray } from "../../redisOperations/redisOperations";

const generateEmptyTable = async (key: string) => `${CONSTANTS.REDIS_COLLECTION.EMPTY_TABLES}:${key}`;

const setEmptyTable = async (lobbyId: string, tableId: string) => {

    logger.log("setEmptyTable", { lobbyId, tableId });

    await addToArray(await generateEmptyTable(lobbyId), tableId);

};

const getEmptyTable = async (lobbyId: string) => {

    logger.log("getEmptyTable", { lobbyId });

    const emptyTableData = await getArray(await generateEmptyTable(lobbyId));

    logger.log("getEmptyTable Return : ", { emptyTableData });

    return emptyTableData;

};

const deleteEmptyTable = async (lobbyId: string, tableId: string) => {

    logger.log("deleteEmptyTable", { lobbyId, tableId });

    await removeFromArray(await generateEmptyTable(lobbyId), tableId);

};

export { setEmptyTable, getEmptyTable, deleteEmptyTable };