import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { UserInTableInterface } from "../../interfaces/userInTable";
import { deleteData, getData, setData } from "../../redisOperations/redisOperations";

const generateUserInTableKey = async (tableId: string, userId: string) => `${CONSTANTS.REDIS_COLLECTION.USER_IN_TABLE}:${tableId}:${userId}`;

const setUserInTable = async (tableId: string, userId: string, userInTableData: UserInTableInterface) => {

    logger.log("setUserInTable", { tableId, userId, userInTableData });

    await setData(await generateUserInTableKey(tableId, userId), userInTableData);

};

const getUserInTable = async (tableId: string, userId: string) => {

    logger.log("getUserInTable", { tableId, userId });

    const userInTableData: UserInTableInterface = await getData(await generateUserInTableKey(tableId, userId));

    logger.log("getUserInTable Return : ", { userInTableData });

    return userInTableData ? userInTableData : Promise.reject(new Error("User In Table Not Found !!!"));

};

const deleteUserInTable = async (tableId: string, userId: string) => {

    logger.log("deleteUserInTable", { tableId, userId });

    await deleteData(await generateUserInTableKey(tableId, userId));

};

export { setUserInTable, getUserInTable, deleteUserInTable };