import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { TableInterface } from "../../interfaces/table";
import { deleteData, getData, setData } from "../../redisOperations/redisOperations";

const generateTableKey = async (key: string) => `${CONSTANTS.REDIS_COLLECTION.TABLES}:${key}`;

const setTable = async (tableId: string, tableData: TableInterface) => {

    logger.log("setTable", { tableId, tableData });

    await setData(await generateTableKey(tableId), tableData);

};

const getTable = async (tableId: string) => {

    logger.log("getTable", { tableId });

    const tableData: TableInterface = await getData(await generateTableKey(tableId));

    logger.log("getTable Return : ", { tableData });

    return tableData ? tableData : Promise.reject(new Error("Table Not Found !!!"));

};

const deleteTable = async (tableId: string) => {

    logger.log("deleteTable", { tableId });

    await deleteData(await generateTableKey(tableId));

};

export { setTable, getTable, deleteTable };