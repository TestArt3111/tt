import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { WinningInterface } from "../../interfaces/winning";
import { deleteData, getData, setData } from "../../redisOperations/redisOperations";

const generateWinningKey = async (key: string) => `${CONSTANTS.REDIS_COLLECTION.WINNING}:${key}`;

const setWinning = async (tableId: string, winningData: WinningInterface) => {

    logger.log("setWinning", { tableId, winningData });

    await setData(await generateWinningKey(tableId), winningData);

};

const getWinning = async (tableId: string) => {

    logger.log("getWinning", { tableId });

    const winningData: WinningInterface = await getData(await generateWinningKey(tableId));

    logger.log("getWinning Return : ", { winningData });

    return winningData ? winningData : Promise.reject(new Error("Winning Not Found !!!"));

};

const deleteWinning = async (tableId: string) => {

    logger.log("deleteWinning", { tableId });

    await deleteData(await generateWinningKey(tableId));

};

export { setWinning, getWinning, deleteWinning };