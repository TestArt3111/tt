import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { UserInterface } from "../../interfaces/user";
import { deleteData, getData, setData } from "../../redisOperations/redisOperations";

const generateUserKey = async (key: string) => `${CONSTANTS.REDIS_COLLECTION.USERS}:${key}`;

const setUser = async (userId: string, userData: UserInterface) => {

    logger.log("setUser", { userId, userData });

    await setData(await generateUserKey(userId), userData);

};

const getUser = async (userId: string) => {

    logger.log("getUser", { userId });

    const userData: UserInterface = await getData(await generateUserKey(userId));

    logger.log("getUser Return : ", { userData });

    return userData ? userData : Promise.reject(new Error("User Not Found !!!"));

};

const deleteUser = async (userId: string) => {

    logger.log("deleteUser", { userId });

    await deleteData(await generateUserKey(userId));

};

export { setUser, getUser, deleteUser };