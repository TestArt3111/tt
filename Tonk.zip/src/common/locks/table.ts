import { Lock } from "redlock";

import { CONSTANTS } from "../../constants";
import { logger } from "../../logger/logger";
import { applyLock } from "../../connection/redLock";

const applyTableLock = async (path: string, tableId: string, delay: number) => {

    try {

        logger.log("applyTableLock", { path, tableId, delay });

        const lockId = `${CONSTANTS.REDIS_COLLECTION.LOCK}:${CONSTANTS.REDIS_COLLECTION.TABLES}:${tableId}`;

        return (await applyLock(path, lockId, delay));

    } catch (error: any) {
        logger.errorLog("applyTableLock Error : ", error);
    };
};

const removeTableLock = async (path: string, lock: Lock) => {

    try {

        logger.log("removeTableLock", { path, lockId: lock?.resources, expiration: lock?.expiration });

        if (lock.expiration) { await lock.release(); };

    } catch (error: any) {
        logger.errorLog("removeTableLock Error : ", error);
    };
};

export { applyTableLock, removeTableLock };