import { randomNumber } from "./randomNumber";

const shuffleArray = async (arr: Array<any>) => {

    const array = [];

    const loopLimit = arr.length;

    for (let i = 0; i < loopLimit; i++) {

        const randomNum = await randomNumber(0, (arr.length - 1));

        array.push(arr.splice(randomNum, 1)[0]);

    };

    return array;

};

export { shuffleArray };