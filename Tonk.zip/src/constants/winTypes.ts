export = Object.freeze({

    TONK: "TONK",
    KNOCK: "KNOCK",
    AUTO_WIN: "AUTO_WIN",
    TONKS_OUT: "TONKS_OUT",

});