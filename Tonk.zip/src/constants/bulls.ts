export = Object.freeze({

    TURN: "turn",
    WIN_DELAY: "winDelay",
    GAME_START: "gameStart",
    TABLE_LOCK: "tableLock",
    TURN_DELAY: "turnDelay",
    CARD_DELAY: "cardDelay",
    DISCONNECT_USER: "disconnectUser",

});