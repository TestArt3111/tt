export = Object.freeze({

    LIVE_ENVIRONMENT: "live",
    TURN_MISSED: "Turn Missed",
    DISCONNECTED: "Disconneted",
    UNKNOWN_EVENT: "Unknown Event",

    MAX_KONCK_LOCK_COUNT: 5,

});