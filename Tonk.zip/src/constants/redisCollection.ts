export = Object.freeze({

    LOCK: "Lock",
    USERS: "Users",
    TABLES: "Tables",
    WINNING: "Winning",
    MATCH_MAKING: "Match_Making",
    EMPTY_TABLES: "Empty_Tables",
    USER_IN_TABLE: "User_In_Table",

});