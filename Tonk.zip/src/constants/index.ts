import CARDS from "./cards";
import BULLS from "./bulls";
import COMMON from "./common";
import WIN_TYPES from "./winTypes";
import EVENTS_NAME from "./eventsName";
import REDIS_COLLECTION from "./redisCollection";

const CONSTANTS = Object.freeze({

    CARDS,
    BULLS,
    COMMON,
    WIN_TYPES,
    EVENTS_NAME,
    REDIS_COLLECTION

});

export { CONSTANTS };