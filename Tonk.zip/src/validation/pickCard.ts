import joi from 'joi';

const validatePickCard = async (data: object) => {

    return joi.object({

        openDeck: joi.boolean().strict().required(),

    }).validate(data)?.error?.details[0]?.message;

};

export { validatePickCard };