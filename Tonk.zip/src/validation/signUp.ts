import joi from 'joi';

const validateSignUp = async (data: object) => {

    return joi.object({

        userId: joi.string().min(1).max(50).required(),
        userName: joi.string().min(2).max(50).required(),
        userProfile: joi.string().min(0).max(250).required(),
        bootValue: joi.number().min(0).strict().required(),
        chips: joi.number().min(1).strict().required(),
        lobbyId: joi.string().min(24).max(24).required()

    }).validate(data)?.error?.details[0]?.message;

};

export { validateSignUp };