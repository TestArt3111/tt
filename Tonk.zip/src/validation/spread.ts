import joi from 'joi';

const validateSpread = async (data: object) => {

    return joi.object({

        cards: joi.array().items(joi.string()).min(3).max(6)

    }).validate(data)?.error?.details[0]?.message;

};

export { validateSpread };