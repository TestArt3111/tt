import joi from 'joi';

const validateHit = async (data: object) => {

    return joi.object({

        cards: joi.array().items(joi.string()).min(1).max(2),
        opponentId: joi.string().min(1).max(50).required(),
        listCount: joi.number().strict().required(),
        selfId: joi.string().min(1).max(50).required()

    }).validate(data)?.error?.details[0]?.message;

};

export { validateHit };