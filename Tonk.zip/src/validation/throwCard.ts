import joi from 'joi';

const validateThrowCard = async (data: object) => {

    return joi.object({

        card: joi.string().min(1).required(),

    }).validate(data)?.error?.details[0]?.message;

};

export { validateThrowCard };