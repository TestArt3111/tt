
import jwt from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";

import { config } from "../../config";
import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";

const auth = async (req: Request, res: Response, next: NextFunction) => {

    try {

        logger.log("API auth", req.headers)

        if (!req.headers?.authorization) {

            return errorRes(req, res, {
                status: 400,
                success: false,
                data: {},
                message: 'Token is require for Authentication'
            });

        };

        const decoded: any = jwt.verify(req.headers?.authorization ?? "", config.jwtSecretKey);

        req.headers.user = decoded;

        next();

    } catch (error: any) {

        logger.errorLog("API auth Error : ", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { auth };