
import { Request, Response } from "express";
import { logger } from "../../logger/logger";

const successRes = async (req: Request, res: Response, data: any) => {

    try {

        logger.log("API successRes", { data });

        res.status(data.status).send({

            status: data.status,
            success: data.success,
            message: data.message,
            data: data.data,

        });

    } catch (error) {
        logger.errorLog("API successRes Error : ", error);
    };
};

export { successRes };
