
import { Request, Response } from "express";
import { logger } from "../../logger/logger";

const errorRes = async (req: Request, res: Response, data: any) => {

    try {

        logger.log("API errorRes", { data });

        res.status(data.status).send({

            status: data.status,
            success: data.success,
            message: data.message,
            data: data.data

        });

    } catch (error) {
        logger.errorLog("API errorRes Error : ", error);
    };
};

export { errorRes };