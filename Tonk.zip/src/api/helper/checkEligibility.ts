
import { logger } from "../../logger/logger";

const getCurrentTimestamp = () => {
    return new Date().toISOString();
}



function getDayDifference(date1: Date, date2: Date): number {
    const normalizedDate1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
    const normalizedDate2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
    logger.log('[getSpinner] :: normalizedDate1', normalizedDate1);
    logger.log('[getSpinner] :: normalizedDate2', normalizedDate2);

    const timeDifference = normalizedDate1.getTime() - normalizedDate2.getTime();
    const dayDifference = Math.floor(timeDifference / (24 * 60 * 60 * 1000));

    return Math.abs(dayDifference);
}


const checkEligibleForDailyReward = async (findUser: any) => {
    try {
        logger.log("checkEligibleForDailyReward", findUser);

        if (!findUser.lastDailyBonusClaimedDateTime || !findUser.isClaimedTodayDailyBonus) {
            return true;
        } else {
            // const currentDateTime = new Date();
            const currentDateTime = new Date(await getCurrentTimestamp());
            logger.log('checkEligibleForDailyReward :: currentDateTime', currentDateTime);

            let lastDailyBonusClaimedDateTime = findUser.lastDailyBonusClaimedDateTime || findUser.createdAt;
            logger.log('checkEligibleForDailyReward :: lastDailyBonusClaimedDateTime', lastDailyBonusClaimedDateTime);

            const daysSinceLastBonus = currentDateTime.getDate() - lastDailyBonusClaimedDateTime.getDate();
            logger.log('checkEligibleForDailyReward :: daysSinceLastSpin', daysSinceLastBonus);

            if (daysSinceLastBonus > 0) {
                return true;
            }
        }
    } catch (error) {
        logger.errorLog("CATCH_ERROR :: checkEligibleForDailyReward", error)
    }
}


const checkEligibleForLuckyWheel = async (findUser: any) => {
    try {
        logger.log("checkEligibleForLuckyWheel", findUser);

        if (!findUser.lastTurnedLuckyWheelDateTime || !findUser.isTurnedLuckyWheel) {
            return true;
        } else {
            let lastTurnedLuckyWheelDateTime = findUser.lastTurnedLuckyWheelDateTime
            let nextTimeForSpinnerClaim = new Date(lastTurnedLuckyWheelDateTime.getTime() + 24 * 60 * 60 * 1000);

            // logger.log(nextTimeForSpinnerClaim.toISOString());
            // let currentTime = new Date("2024-04-22T04:08:59.776Z");
            let currentTime = new Date();

            if (currentTime >= lastTurnedLuckyWheelDateTime && currentTime <= nextTimeForSpinnerClaim) {
                logger.log("not EligibleForLuckyWheel ", false);
                return false;
            } else {
                logger.log("EligibleForLuckyWheel", true);
                return true;
            }
        }
    } catch (error) {
        logger.errorLog("CATCH_ERROR :: checkEligibleForLuckyWheel", error)
    }
}


export { getCurrentTimestamp, getDayDifference, checkEligibleForDailyReward, checkEligibleForLuckyWheel };
