import moment from "moment";
import { logger } from "../../logger/logger";


const gameMaintenance = async (startDate: any, endDate: any) => {
    try {
        logger.log("gameMaintenance ::startDate : ,endDate : ", startDate, endDate);
        //  maintenance 
        const maintenanceStartTime = moment(startDate);
        const maintenanceEndTime = moment(endDate);

        // Get the current time
        const currentTime = moment();
        logger.log("currentTime ::: ", currentTime);

        // Check if the current time is within the maintenance window
        if (currentTime.isBetween(maintenanceStartTime, maintenanceEndTime)) {
            logger.log('Maintenance is active. Cannot insert player at the current time...', true);

            return true;
        } else {
            logger.log('Maintenance is inactive....', false);
            return false;
        }
    } catch (error) {
        logger.errorLog("CATCH_ERROR :: gameMaintenance", error)
    }
}
export { gameMaintenance };