import mongoose from 'mongoose';

const inAppStoreHistorySchema = new mongoose.Schema({

    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    inAppId: { type: mongoose.Schema.Types.ObjectId, ref: 'InAppStore', require: true },
    packageId: { type: String, require: true },
    name: { type: String, },
    price: { type: Number, required: true },
    items: { type: String, required: true },
    coins: { type: Number, required: true },
    numericId: { type: Number, default: 0 },

}, { timestamps: true, versionKey: false, });

inAppStoreHistorySchema.pre('save', async function (next) {

    const maxNumber = await InAppStoreHistoryModel.findOne().sort({ "numericId": -1 });
    let maxNumberId = 1;

    if (maxNumber && maxNumber.numericId) { maxNumberId = maxNumber.numericId + 1; }

    const doc = this;
    doc.numericId = maxNumberId;

    next();

});

const InAppStoreHistoryModel = mongoose.model('InAppStoreHistory', inAppStoreHistorySchema);

export { InAppStoreHistoryModel };