import Joi from "joi";
import mongoose from "mongoose";

const userSchema = new mongoose.Schema({

    email: { type: String, trim: true },
    phoneNumber: { type: String },
    profileImage: { type: String, },
    userName: { type: String, required: true, },
    nickName: { type: String, },
    referralCode: { type: String, },
    deviceId: { type: String, required: true, },
    address: { type: String, default: "", },
    state: { type: String, default: "Gujarat", },
    country: { type: String, default: "India", },
    password: { type: String, },
    role: { type: String, required: true, },
    isBlock: { type: Boolean, default: false, },
    lastActivateAt: { type: Date, default: Date.now, },
    bonus: { type: Number, },
    winCash: { type: Number, },
    cash: { type: Number, },
    chips: { type: Number, },
    totalDeposits: { type: Number, },
    totalWithdrawals: { type: Number, },
    totalEarnings: { type: Number, default: 0, },
    timeZone: { type: String, },
    numericId: { type: Number, default: 0, },
    isBot: { type: Boolean, default: false, },
    token: { type: String, },
    isGuestLogin: { type: Boolean, default: true },
    title: { type: String },
    avatarId: { type: String, required: false },
    avatarURL: { type: String, required: false },
    commission: { type: Number },
    platformFee: { type: Number },
    deviceType: { type: String, default: "Android" },
    payoutMethod: { type: String },
    isReceivePromotions: { type: Boolean },
    isUseCookie: { type: Boolean },
    profilePicKey: { type: String },
    isAvatarAsProfileImage: { type: Boolean, default: false },
    ipAddress: { type: String, default: "127.0.0.1" },
    isUserFirstTime: { type: Boolean, },
    longitude: { type: String },
    latitude: { type: String },
    adminUserPermission: { type: Object },
    notificationToken: { type: String },
    isUserDeleteAcount: { type: Boolean, default: false },
    userDeleteAccountAt: { type: Date },
    isAllowNotifications: { type: Boolean, default: true },
    totalGames: { type: Number, default: 0 },
    winGames: { type: Number, default: 0 },
    loseGames: { type: Number, default: 0 },
    tieGames: { type: Number, default: 0 },
    version: { type: String, default: "0.0.1" },
    dailyRewards: [],
    lastDailyBonusClaimedDateTime: { type: Date, default: '' },
    lastTurnedLuckyWheelDateTime: { type: Date, default: "" },
    nextTimeForSpinnerClaim: { type: Date, default: "" },

    lastOfferClaimDate: { type: Date, default: '' },
    isTurnedLuckyWheel: { type: Boolean, default: false },
    isOfferTakeToday: { type: Boolean, default: false },
    isClaimedTodayDailyBonus: { type: Boolean, },

}, { timestamps: true, versionKey: false, });

userSchema.pre("save", async function (next) {

    const doc = this;

    if (!doc.numericId) {

        const count = await User.countDocuments();

        if (count === 0) {

            doc.numericId = 1;

        } else {

            const maxNumber: any = await User.findOneAndUpdate({}, { $inc: { numericId: 1 } }, { sort: { numericId: -1 }, new: true });

            doc.numericId = maxNumber.numericId;

        };
    };

    next();

});

export const User = mongoose.model('User', userSchema);

export const validateUser = (user: any) => {

    const schema = Joi.object().keys({
        userName: Joi.string().allow("").required(),
        deviceId: Joi.string().required(),
        profileImage: Joi.string().allow("").required(),
        token: Joi.string().allow("").required()

    });

    return schema.validate(user);

};