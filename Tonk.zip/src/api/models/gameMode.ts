import mongoose from "mongoose";

const gameModeSchema = new mongoose.Schema({

    gameModeName: { type: String, required: true },
    gameModeIcon: { type: String },
    position: { type: Number },
    numericId: { type: Number, default: 0 },
    isActive: { type: Boolean, required: true },
    createAdminId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    updateAdminId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },

}, { timestamps: true, versionKey: false });


const GameModeModel = mongoose.model('GameMode', gameModeSchema);

export { GameModeModel };