import mongoose from 'mongoose';

const gameConfigSchema = new mongoose.Schema({

    gameId: { type: mongoose.Schema.Types.ObjectId, ref: 'Game', index: true },
    gameConfig: { type: Object, require: true },
    numericId: { type: Number, default: 0 }

}, { timestamps: true, versionKey: false });


const gameConfigModel = mongoose.model('GameConfig', gameConfigSchema);

export { gameConfigModel };