import mongoose from 'mongoose';

const maintenanceSchema = new mongoose.Schema({

    title: { type: String, required: true },
    description: { type: String, required: true },
    maintenanceImage: { type: String, required: true },
    maintenanceImageKey: { type: String, required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true, },
    numericId: { type: Number, default: 0 }

}, { timestamps: true, versionKey: false });

const MaintenanceModel = mongoose.model('SettingMaintenance', maintenanceSchema);

export { MaintenanceModel };