import mongoose from 'mongoose';

const inAppStoreSchema = new mongoose.Schema({

    packageId: { type: String, require: true },
    name: { type: String, required: true, index: true },
    title: { type: String, required: true },
    price: { type: Number, required: true },
    items: { type: String, required: true },
    coins: { type: Number, required: true },
    inAppStoreImage: { type: String, required: true },
    inAppStoreImageKey: { type: String },
    inAppCoins: { type: Number, default: 0 },
    offerDiscount: { type: String },
    platform: { type: String, required: true },
    numericId: { type: Number, default: 0 }

}, { timestamps: true, versionKey: false });


inAppStoreSchema.pre('save', async function (next) {

    const maxNumber = await InAppStoreModel.findOne().sort({ numericId: -1 });
    let maxNumberId = 1;

    if (maxNumber && maxNumber.numericId) { maxNumberId = maxNumber.numericId + 1; }

    const doc = this;
    doc.numericId = maxNumberId;

    next();

});

const InAppStoreModel = mongoose.model('InAppStore', inAppStoreSchema);

export { InAppStoreModel };