import mongoose from "mongoose";
import { USER_GAME_RUNNING_STATUS } from "../constant";

const gameRunningSchema = new mongoose.Schema({

    userId: { type: String },
    tableId: { type: String },
    lobbyId: { type: String },
    status: { type: String, default: USER_GAME_RUNNING_STATUS.RUNNING },
    gameModeId: { type: String },

}, { versionKey: false });

const Gamerunning = mongoose.model('Gamerunning', gameRunningSchema);

export { Gamerunning };