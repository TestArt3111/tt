import mongoose from "mongoose";

const tournamentSchema = new mongoose.Schema({

    tournamentName: { type: String, trim: true },
    publisherId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },

    description: { type: String, trim: true },
    entryfee: { type: Number, required: true },
    minChips: { type: Number, required: true },
    maxChips: { type: Number, required: true },
    isGameModeOption: { type: Boolean, required: true },
    gameModeId: { type: mongoose.Schema.Types.ObjectId, ref: 'GameMode' },
    isCash: { type: Boolean, default: false },
    isActive: { type: Boolean, required: true },
    numericId: { type: Number, default: 0 },
    minPlayer: { type: Number },
    maxPlayer: { type: Number },

    noOfPlayer: { type: Number, },
    winningPrice: { type: Number, required: true },

}, { timestamps: true, versionKey: false });

const TournamentModel = mongoose.model('Tournament', tournamentSchema);

export { TournamentModel };