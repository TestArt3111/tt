export interface userIF {
    userName: string;
    deviceId: string;
    profilePicture: string;
    token: string
}

export interface userDataIf {
    _id: string;
    role: string;
    deviceId: string;
}

export interface feedBackIF {
    email: string;
    feedBack: string;
}

export interface gameModeIF {
    gameModeId: string;
}