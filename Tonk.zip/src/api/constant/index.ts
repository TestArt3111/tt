const USER_GAME_RUNNING_STATUS = {
    RUNNING: 'RUNNING'
};

const DAILY_WHEEL_BONUS_ROWS = [2, 4, 6, 8];

const NUMERICAL = {
    ZERO: 0,
    ONE: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
    SIX: 6,
    SEVEN: 7,
    EIGHT: 8,
    NINE: 9,
    TEN: 10,
    ELEVEN: 11,
    TWELVE: 12,
    THIRTEEN: 13,
    THIRTY: 30,
    HUNDRED: 100,
    FIFTY: 50,
    SIXTY: 60,
    THOUSAND: 1000,
    TEN_THOUSAND: 10000,
    ONE_HOUR: 3600
};

export { USER_GAME_RUNNING_STATUS, DAILY_WHEEL_BONUS_ROWS, NUMERICAL };
