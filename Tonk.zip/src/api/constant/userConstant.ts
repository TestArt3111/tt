const USER_CONSTANTS = {

    USER_ROLE: {
        USER: "User",
        ADMIN: "Admin",
    },

    ROLES_ARRAY: ['Admin', 'User'],

    SIGNUP: {
        COIN: 100000,
        CASH: 500,
        BONUS: 50,
    },

    AGENT_ROLES_ARRAY: ['AdminUser', 'SubAdminUser'],
    PUBLISHER_STATUS_ARRAY: ['pending', 'approve', 'reject'],
    DEFAULT_COINS: 1000,
    DEFAULT_BONUS: 1000,
    DEVICE_TYPE_ARRAY: ['Android', 'Ios'],
    DEFAULT_PUBLISHER_EARNINGS: 1000,
    PREFERENCE_KEY_ARRAY: ['isReceivePromotions', 'isUseCookie'],
    DEFAULT_PLATFORM_FEE: 10,
    PROFILE_IMAGE_EXT_ARRAY: ['.jpeg', '.jpg', '.png'],
    PROFILE_IMAGE_FILE_SIZE: 5, // 5 MB
    DEFAULT_VIRTUAL_MONEY_COINS: 1000,
    SIGNUP_COIN: 0,

    BOT_DEFAULT: {
        LONGITUDE: '0',
        LATITUDE: '0'
    },

    USER_DELETE_ACCOUNT_DAYS: 15,

    DAILY_REWARD: [
        { day: 1, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 2, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 3, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 4, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 5, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 6, isClaimed: false, lostClaim: false, isCurrentClaim: false },
        { day: 7, isClaimed: false, lostClaim: false, isCurrentClaim: false },
    ],

    REFILL_HEALTH: 10,
    DEDUCT_REFILL_HEALTH_COINS: 500,

    GAME_STATE: [
        { gameMode: "1_Card", gamePlayed: 0, gameWon: 0, gameLoss: 0 },
        { gameMode: "2_Card", gamePlayed: 0, gameWon: 0, gameLoss: 0 },
        { gameMode: "4_Card", gamePlayed: 0, gameWon: 0, gameLoss: 0 }
    ]

};

export { USER_CONSTANTS };