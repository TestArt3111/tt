import { User } from "../models/user";
import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";
import { gameConfigModel } from "../models/gameConfig";
import { gameMaintenance } from "../helper/maintenance";
import { MaintenanceModel } from "../models/maintenance";
import { USER_CONSTANTS } from "../constant/userConstant";

const getDailyBonus = async (req: any, res: any) => {

    try {

        logger.log("API getDailyBonus", { Headers: req.headers });

        const responseData = { isMaintenance: false, rewardData: [] };

        const findUser: any = await User.findById(req.headers.user._id);

        if (!findUser) {

            return successRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData },
                message: 'addGameRunning Successfully.'
            });

        };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        if (isMaintenance) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData, isMaintenance: true },
                message: getMaintenance.description
            });

        };

        const dailyBonusChips: any = await gameConfigModel.findOne({});

        if (!dailyBonusChips) { throw new Error("dailyRewards not found"); };

        const dayCoins = JSON.parse(dailyBonusChips.gameConfig.REWARD_DAY_WISE_OBJECT.replaceAll(`'`, `"`));

        const currentDay: any = new Date();

        const createdUser: any = new Date(findUser.createdAt);

        const createdUserDay: any = new Date(createdUser.getFullYear(), createdUser.getMonth(), createdUser.getDate());

        const daysDiffOfUserCreated = Math.ceil((Math.abs(currentDay - createdUserDay)) / (24 * 60 * 60 * 1000));

        const weekDayOfUser = (daysDiffOfUserCreated % 7) === 0 ? 7 : (daysDiffOfUserCreated % 7);

        const lastCalimed: any = new Date(findUser.lastDailyBonusClaimedDateTime ? findUser.lastDailyBonusClaimedDateTime : findUser.createdAt);

        const lastCalimedDay: any = new Date(lastCalimed.getFullYear(), lastCalimed.getMonth(), lastCalimed.getDate());

        const daysDiffOfLastCalim = Math.ceil((Math.abs(currentDay - lastCalimedDay)) / (24 * 60 * 60 * 1000));

        const updatedRewards = (daysDiffOfLastCalim >= 7 && daysDiffOfUserCreated >= 7)

            ? JSON.parse(JSON.stringify(USER_CONSTANTS.DAILY_REWARD))
                .map((e: any) => { return { ...e, isCurrentClaim: false, coins: dayCoins[`${e.day}`] } })
                .map((e: any) => { return (weekDayOfUser) === e.day ? { ...e, isCurrentClaim: true } : { ...e } })
                .map((e: any) => { return (weekDayOfUser > e.day && !e.isClaimed) ? { ...e, lostClaim: true } : { ...e } })

            : JSON.parse(JSON.stringify(findUser.dailyRewards))
                .map((e: any) => { return { ...e, isCurrentClaim: false, coins: dayCoins[`${e.day}`] } })
                .map((e: any) => { return (weekDayOfUser) === e.day ? { ...e, isCurrentClaim: true } : { ...e } })
                .map((e: any) => { return (weekDayOfUser > e.day && !e.isClaimed) ? { ...e, lostClaim: true } : { ...e } })

        await User.findOneAndUpdate({ _id: findUser._id }, { $set: { dailyRewards: updatedRewards } });

        successRes(req, res, {
            status: 200,
            success: true,
            message: 'get dailyReward successfully',
            data: { ...responseData, rewardData: updatedRewards }
        });

    } catch (error: any) {

        logger.errorLog("API getDailyBonus Error : ", error);

        return errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

const claimDailyBonus = async (req: any, res: any) => {

    try {

        logger.log("API claimDailyBonus", { Headers: req.headers, Body: req.body });

        const responseData = {}

        const findUser: any = await User.findById(req.headers.user._id);

        if (!findUser) {

            return successRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData },
                message: 'user Not Found !!!'
            });

        };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        if (isMaintenance) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData, isMaintenance: true },
                message: getMaintenance.description
            });

        };

        const currentDay: any = new Date();

        const createdUser: any = new Date(findUser.createdAt);

        const daysDiffOfUserCreated = Math.ceil((Math.abs(currentDay - createdUser)) / (24 * 60 * 60 * 1000));

        const weekDayOfUser = (daysDiffOfUserCreated % 7) === 0 ? 7 : (daysDiffOfUserCreated % 7);

        const { day } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;

        if (weekDayOfUser !== day) {

            return errorRes(req, res, {
                status: 400,
                success: false,
                data: {},
                message: 'Day Mismatch'
            });

        };

        const currentBonusDay = findUser.dailyRewards.find((obj: any) => obj.day === day);

        if (!currentBonusDay) { throw new Error("Failed To Find Current Bonus Day !!!"); };

        if (currentBonusDay.isCurrentClaim === false || currentBonusDay.lostClaim === true || currentBonusDay.isClaimed === true) {

            return errorRes(req, res, {
                status: 400,
                success: false,
                data: {},
                message: 'You Have No More Claim Reward'
            });

        };

        const updatedRewards = findUser.dailyRewards.map((e: any) => e.isCurrentClaim ? { ...e, isCurrentClaim: false, isClaimed: true } : { ...e });

        await User.findOneAndUpdate({ _id: findUser._id }, { $set: { dailyRewards: updatedRewards, lastDailyBonusClaimedDateTime: new Date() }, $inc: { chips: Number(currentBonusDay.coins) } })

        successRes(req, res, {
            status: 200,
            success: true,
            message: 'claimDailyBonus successfully',
            data: { ...currentBonusDay, chips: (Number(findUser?.chips) + Number(currentBonusDay.coins)) }
        });

    } catch (error: any) {

        logger.errorLog("API claimDailyBonus Error : ", error);

        return errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { getDailyBonus, claimDailyBonus }