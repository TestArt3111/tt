import { User } from "../models/user";
import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";
import { InAppStoreModel } from "../models/inAppStore";
import { gameMaintenance } from "../helper/maintenance";
import { MaintenanceModel } from "../models/maintenance";

const getStoreData = async (req: any, res: any) => {

    try {

        logger.log("API getStoreData", { Headers: req.headers });

        const responseData = { isMaintenance: false, storeData: {} };

        const userData: any = await User.findById(req.headers.user._id);

        if (!userData) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: {},
                message: 'getLobby :: User Not Exist.'
            });

        };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        if (isMaintenance) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData, isMaintenance: true },
                message: getMaintenance.description
            });

        };

        const storeData = await InAppStoreModel.find({}).lean();

        successRes(req, res, {
            status: 200,
            success: true,
            message: 'get storeData Successfully.',
            data: { ...responseData, storeData }
        });

    } catch (error: any) {

        logger.errorLog("API getStoreData Error : ", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { getStoreData };