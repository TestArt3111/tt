import { User } from "../models/user";
import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";
import { InAppStoreModel } from "../models/inAppStore";
import { gameMaintenance } from "../helper/maintenance";
import { MaintenanceModel } from "../models/maintenance";
import { InAppStoreHistoryModel } from "../models/inAppStoreHistory";

const purchaseCoin = async (req: any, res: any) => {

    try {

        logger.log("API purchaseCoin", { Body: req.body, Header: req.headers });

        const responseData = { isMaintenance: false, purchaseCoin: 0 };

        const userData: any = await User.findById(req.headers.user._id);

        if (!userData) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: {},
                message: 'getLobby :: User Not Exist.'
            });

        };

        const { _id, quantity, price } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;

        if (!Number.isInteger(quantity) || quantity <= 0) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData },
                message: "Please Provide Valid Quentity"
            });

        };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        if (getMaintenance) {

            let isMaintenance = await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate);

            if (isMaintenance) {

                return errorRes(req, res, {
                    status: 404,
                    success: false,
                    data: { ...responseData, isMaintenance: true },
                    message: getMaintenance.description
                });

            };
        };

        const storePackage = await InAppStoreModel.findOne({ packageId: _id });

        if (!storePackage) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData },
                message: "Package Not Found"
            });

        };

        for (let i = 0; i < quantity; i++) {

            await InAppStoreHistoryModel.create({

                userId: userData._id,
                inAppId: storePackage._id,
                packageId: storePackage.packageId,
                name: storePackage.name,
                price: Number(price),
                items: storePackage.items,
                coins: (Number(storePackage.coins) * Number(quantity)),

            });

        };

        await User.findByIdAndUpdate(userData._id, { $inc: { chips: (storePackage.coins * Number(quantity)) } }, { returnDocument: 'after' }).lean();

        successRes(req, res, {
            status: 200,
            success: true,
            message: 'purchaseCoin Successfully.',
            data: { ...responseData, purchaseCoin: (storePackage.coins * Number(quantity)) }
        });

    } catch (error: any) {

        logger.errorLog("API purchaseCoin Error : ", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { purchaseCoin };