import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";
import { gameMaintenance } from "../helper/maintenance";
import { MaintenanceModel } from "../models/maintenance";
import { User } from "../models/user";


const addFreeCoin = async (req: any, res: any) => {
    try {

        const user = req.headers.user;
        logger.log('addFreeCoin :: deviceId', user);

        const findUser: any = await User.findById(user._id);
        logger.log("addFreeCoin :: findUser if ", findUser);
        if (!findUser) {
            let coinData = {
                status: 404,
                success: false,
                data: {},
                message: 'addFreeCoin :: User Not Exist.'
            }
            return errorRes(req, res, coinData)
        }

        const getMaintenance: any = await MaintenanceModel.findOne({});
        logger.log("addFreeCoin :: getMaintenance", getMaintenance);
        if (getMaintenance) {
            let isMaintenance = await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate);
            logger.log("addFreeCoin :: maintenance", isMaintenance)
            if (isMaintenance) {
                let data = {
                    status: 404,
                    success: false,
                    data: {
                        isMaintenance: true
                    },
                    // message: "Maintenance is active. Cannot insert player at the current time"
                    message: getMaintenance.description
                }
                return errorRes(req, res, data);
            }
        }

        let Coin: any = [100, 200, 300, 400, 500];

        let randomIndex = Math.floor(Math.random() * Coin.length);
        logger.log("randomIndex ::: ", randomIndex);

        let randomValue: number = Coin[randomIndex];

        logger.log("randomValue ::;", randomValue);

        let updatedCoins = findUser.chips + randomValue;
        const userData = await User.findByIdAndUpdate(user._id, {
            $set: {
                chips: updatedCoins
            }
        }, { returnDocument: 'after' });

        logger.log('addFreeCoin :: userData', userData);
        let updatedUser = {
            chips: userData?.chips,
            freeCoin: randomValue
        }
        let Data = {
            status: 200,
            success: true,
            message: 'addFreeCoin Successfully.',
            data: updatedUser
        }
        logger.log('addFreeCoin :: Data', Data);

        return successRes(req, res, Data)

    } catch (error: any) {

        logger.errorLog("CATCH_ERROR :: addFreeCoin", error);
        let data = {
            status: 400,
            success: false,
            data: {},
            message: error.message
        }
        return errorRes(req, res, data)
    }
};
export { addFreeCoin }