import rs from "randomstring";
import jwt from "jsonwebtoken";
import bcryptjs from "bcryptjs";

import { config } from "../../config";
import { userDataIf } from "../interface";
import { logger } from "../../logger/logger";
import { GameModeModel } from "../models/gameMode";
import { errorRes } from "../common/errorResponse";
import { User, validateUser } from "../models/user";
import { successRes } from "../common/successResponse";
import { USER_CONSTANTS } from "../constant/userConstant";
import { checkEligibleForDailyReward, checkEligibleForLuckyWheel } from "../helper/checkEligibility";

const userRegister = async (req: any, res: any) => {

    try {

        logger.log("API userRegister", req.body);

        const { userName, deviceId, profileImage, token } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;

        const { error } = validateUser({ userName, deviceId, profileImage, token });

        if (error) {

            return errorRes(req, res, {
                status: 500,
                success: false,
                data: {},
                message: error.details[0].message
            });

        };

        const gameMode = await GameModeModel.find({});

        if (token) {

            const decoded = jwt.verify(token, config.jwtSecretKey) as userDataIf;

            const findUser: any = await User.findById(decoded._id).lean();

            if (!findUser || findUser.isBlock) {

                return errorRes(req, res, {
                    status: 404,
                    success: false,
                    data: {},
                    message: findUser?.isBlock ? "You Can't Play Because You Are Block" : "user not found"
                });

            };

            const isDailyBonus = await checkEligibleForDailyReward(findUser);

            successRes(req, res, {
                status: 200,
                success: true,
                message: 'User Already Exists.',
                data: { ...findUser, gameMode, isDailyBonus, isNewUser: false }
            });

        } else {

            const findUser: any = await User.findOne({ deviceId }).lean();

            if (findUser) {

                if (findUser.isBlock) {

                    return errorRes(req, res, {
                        status: 404,
                        success: false,
                        data: {},
                        message: "You Can't Play Because You Are Block"
                    });

                };

                const isDailyBonus = await checkEligibleForDailyReward(findUser);

                successRes(req, res, {
                    status: 200,
                    success: true,
                    message: 'User Already Exists.',
                    data: { ...findUser, gameMode, isDailyBonus, isNewUser: false }
                });

            } else {

                const newUser = await User.create({

                    userName: userName,
                    deviceId: deviceId,
                    profileImage: profileImage,
                    role: USER_CONSTANTS.USER_ROLE.USER,
                    email: `${userName}@gmail.com`,
                    phoneNumber: 5476768785,
                    password: `${userName}1234`,
                    referralCode: rs.generate(6),
                    bonus: USER_CONSTANTS.SIGNUP.BONUS,
                    winCash: 0,
                    cash: USER_CONSTANTS.SIGNUP.CASH,
                    chips: USER_CONSTANTS.SIGNUP.COIN,
                    totalDeposits: 0,
                    totalWithdrawals: 0,
                    dailyRewards: USER_CONSTANTS.DAILY_REWARD,
                    timeZone: "Asia/Kolkata",

                });

                if (!newUser) {

                    return errorRes(req, res, {
                        status: 500,
                        success: false,
                        data: {},
                        message: "Failed To Create New User"
                    });

                };

                const encPassword = await bcryptjs.hash(newUser.password ?? "", 10);

                const token = jwt.sign({ role: USER_CONSTANTS.USER_ROLE.USER, deviceId: deviceId, _id: newUser._id, password: encPassword }, config.jwtSecretKey);

                const updatedUser = await User.findByIdAndUpdate(newUser._id, { $set: { token, password: encPassword } }, { returnDocument: "after" }).lean();

                successRes(req, res, {
                    status: 200,
                    success: true,
                    message: 'User Register Successfully.',
                    data: { ...updatedUser, password: encPassword, gameMode, isDailyBonus: true, isNewUser: true },
                });

            };

        };

    } catch (error: any) {

        logger.errorLog("API userRegister Error : ", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

const updateUserProfile = async (req: any, res: any) => {

    try {


        const userData: any = await User.findById(req.headers.user._id);

        if (!userData) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: {},
                message: 'User Not Exist.'
            });

        };

        const { userName, profileImage } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;

        if (!userName || !userName.trim()) {

            return errorRes(req, res, {
                status: 400,
                success: false,
                data: {},
                message: 'userName not valid'
            });

        };

        const updatedUser = await User.findByIdAndUpdate(userData._id, { $set: { userName, profileImage } }, { returnDocument: 'after' }).lean();

        if (!updatedUser) {

            return errorRes(req, res, {
                status: 500,
                success: false,
                data: {},
                message: 'Failed To Update User.'
            });

        };

        successRes(req, res, {
            status: 200,
            success: true,
            data: { userName: updatedUser.userName, profileImage: updatedUser.profileImage },
            message: 'Update Userprofile Successfully.',
        });

    } catch (error: any) {

        logger.errorLog("CATCH_ERROR :: updateUserProfile", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { userRegister, updateUserProfile };