import { User } from "../models/user";
import { logger } from "../../logger/logger";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";
import { Gamerunning } from "../models/addGameRunning";
import { USER_GAME_RUNNING_STATUS } from "../constant";
import { gameMaintenance } from "../helper/maintenance";
import { MaintenanceModel } from "../models/maintenance";
import { getUser } from "../../common/gameRedisOperations/user";
import { getTable } from "../../common/gameRedisOperations/table";
import { getUserInTable } from "../../common/gameRedisOperations/userInTable";

const addGameRunning = async (req: any, res: any) => {

    try {

        logger.log("API addGameRunning", req.body);

        const { deviceId } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;

        const responseData = { isMaintenance: false, isUserFirstTime: false, isRunningGame: false, userData: {} };

        const getMaintenance: any = await MaintenanceModel.findOne({});

        const isMaintenance = getMaintenance ? await gameMaintenance(getMaintenance.startDate, getMaintenance.endDate) : false;

        if (isMaintenance) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: { ...responseData, isMaintenance: true },
                message: getMaintenance.description
            });

        };

        const findUser: any = await User.findOne({ deviceId });

        if (!findUser) {

            return successRes(req, res, {
                status: 200,
                success: true,
                data: { ...responseData, isUserFirstTime: true },
                message: 'addGameRunning Successfully.'
            });

        };

        const findRunningGameData: any = await Gamerunning.findOne({ userId: deviceId, status: USER_GAME_RUNNING_STATUS.RUNNING });

        if (findRunningGameData) {

            const user = await getUser(findRunningGameData.userId);

            await getTable(findRunningGameData.tableId);

            await getUserInTable(findRunningGameData.tableId, findRunningGameData.userId);

            return successRes(req, res, {
                status: 200,
                success: true,
                data: { ...responseData, isRunningGame: true, userData: user },
                message: 'addGameRunning Successfully.'
            });

        } else {

            return successRes(req, res, {
                status: 200,
                success: true,
                data: { ...responseData },
                message: 'addGameRunning Successfully.'
            });

        };

    } catch (error: any) {

        logger.errorLog("API addGameRunning Error : ", error);

        errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { addGameRunning };