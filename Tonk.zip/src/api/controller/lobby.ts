import { User } from "../models/user";
import { logger } from "../../logger/logger";
import { TournamentModel } from "../models/lobby";
import { errorRes } from "../common/errorResponse";
import { successRes } from "../common/successResponse";

const getLobby = async (req: any, res: any) => {

    try {

        logger.log("API getLobby", req.body);

        const userData: any = await User.findById(req.headers.user._id);

        if (!userData) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: {},
                message: 'getLobby :: User Not Exist.'
            });

        };

        let { gameModeId } = (typeof req.body.data == "string") ? JSON.parse(req.body.data) : req.body.data;
        
        const lobbyList: any = await TournamentModel.find({isActive: true }).sort({ entryFee: 1 }).lean();
        console.log("000000:-"+lobbyList);
        if (!lobbyList.length) {

            return errorRes(req, res, {
                status: 404,
                success: false,
                data: {},
                message: 'No Lobby Found !'
            });

        };

        lobbyList.forEach((lobby: any) => { lobby.isCanPlay = (lobby.entryfee * 2) <= userData.chips; });

        successRes(req, res, {
            status: 200,
            success: true,
            message: 'lobby get successfully.',
            data: { lobbyList }
        });

    } catch (error: any) {

        logger.errorLog("API getLobby Error : ", error);

        return errorRes(req, res, {
            status: 400,
            success: false,
            data: {},
            message: error.message
        });

    };
};

export { getLobby };