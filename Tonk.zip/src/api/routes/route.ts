import express from "express";
import { auth } from "../middleware/auth";
import { getLobby } from "../controller/lobby";
import { getStoreData } from "../controller/getStore";
import { purchaseCoin } from "../controller/purchaseCoin";
import { addGameRunning } from "../controller/addGameRunning";
import { userRegister, updateUserProfile } from "../controller/user";

import { claimDailyBonus, getDailyBonus } from "../controller/dailyBonus";
// import { claimLuckyWheel, getSpinner } from "../controller/spinner";
// import { userFeedBack } from "../controller/userFeedBack";
// import { addFreeCoin } from "../controller/addCoin";

const router = express.Router();

router.post('/getLobby', auth, getLobby);
router.post('/addGameRunningStatus', addGameRunning);

router.post('/userRegister', userRegister);
router.post('/editUserProfile', auth, updateUserProfile);

router.post('/getStoreData', auth, getStoreData);
router.post('/purchaseCoin', auth, purchaseCoin);

// router.post('/userFeedBack', auth, userFeedBack);
// router.post('/addFreeCoin', auth, addFreeCoin);

router.post('/getDailyBonus', auth, getDailyBonus);
router.post('/claimDailyBonus', auth, claimDailyBonus);

// router.post('/getSpinner', auth, getSpinner);
// router.post('/claimLuckyWheel', auth, claimLuckyWheel);

export { router }; 
