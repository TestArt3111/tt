import "dotenv/config";

import { logger } from "./logger/logger";
import { initialize } from "./connection/init";
import { debug } from "console";

console.log("start with apps");

initialize();


process.on("uncaughtException", (error: any) => {

    logger.errorLog("uncaughtException : Error : ", error);

});

process.on("unhandledRejection", (response: any, error: any) => {

    logger.errorLog("unhandledRejection : response : ", response);
    logger.errorLog("unhandledRejection: error : ", error);

});