import bull, { QueueOptions } from "bull";

import { config } from "../../config";
import { CONSTANTS } from "./../../constants";

interface BullQueueType extends bull.Queue { };

const bullOptions: QueueOptions = {

    redis: {
        host: config.redis.REDIS_HOST,
        port: config.redis.REDIS_PORT,
        password: config.redis.REDIS_PASSWORD,
        db: config.redis.REDIS_DATABASE_NUMBER
    },
    prefix: "Bull",

};

const turnBull: BullQueueType = new bull(CONSTANTS.BULLS.TURN, bullOptions);
const winDelayBull: BullQueueType = new bull(CONSTANTS.BULLS.WIN_DELAY, bullOptions);
const gameStartBull: BullQueueType = new bull(CONSTANTS.BULLS.GAME_START, bullOptions);
const tableLockBull: BullQueueType = new bull(CONSTANTS.BULLS.TABLE_LOCK, bullOptions);
const turnDelayBull: BullQueueType = new bull(CONSTANTS.BULLS.TURN_DELAY, bullOptions);
const cardDelayBull: BullQueueType = new bull(CONSTANTS.BULLS.CARD_DELAY, bullOptions);
const disconnectUserBull: BullQueueType = new bull(CONSTANTS.BULLS.DISCONNECT_USER, bullOptions);

export {

    turnBull,
    winDelayBull,
    gameStartBull,
    tableLockBull,
    turnDelayBull,
    cardDelayBull,
    disconnectUserBull,

};