import { Job } from "bull";

import { logger } from "../../logger/logger";
import { tableLockBull } from "../allQueues/allQueues";

const tableLockGet = async (tableId: string) => {

    try {

        logger.log("tableLockGet", { tableId });

        const job: (Job | null) = await tableLockBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("tableLockGet Error : ", error);
    };
};

export { tableLockGet };