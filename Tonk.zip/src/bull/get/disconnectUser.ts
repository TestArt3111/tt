import { Job } from "bull";

import { logger } from "../../logger/logger";
import { disconnectUserBull } from "../allQueues/allQueues";

const disconnectUserGet = async (userId: string) => {

    try {

        logger.log("disconnectUserGet", { userId });

        const job: (Job | null) = await disconnectUserBull.getJob(userId);

        return job;

    } catch (error: any) {
        logger.errorLog("disconnectUserGet Error : ", error);
    };
};

export { disconnectUserGet };