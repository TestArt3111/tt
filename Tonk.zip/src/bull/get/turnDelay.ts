import { Job } from "bull";

import { logger } from "../../logger/logger";
import { turnDelayBull } from "../allQueues/allQueues";

const turnDelayGet = async (tableId: string) => {

    try {

        logger.log("turnDelayGet", { tableId });

        const job: (Job | null) = await turnDelayBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("turnDelayGet Error : ", error);
    };

};

export { turnDelayGet };