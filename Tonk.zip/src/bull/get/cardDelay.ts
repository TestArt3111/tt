import { Job } from "bull";

import { logger } from "../../logger/logger";
import { cardDelayBull } from "../allQueues/allQueues";

const cardDelayGet = async (tableId: string) => {

    try {

        logger.log("cardDelayGet", { tableId });

        const job: (Job | null) = await cardDelayBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("cardDelayGet Error : ", error);
    };
};

export { cardDelayGet };
