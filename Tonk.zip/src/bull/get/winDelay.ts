import { Job } from "bull";

import { logger } from "../../logger/logger";
import { winDelayBull } from "../allQueues/allQueues";

const winDelayGet = async (tableId: string) => {

    try {

        logger.log("winDelayGet", { tableId });

        const job: (Job | null) = await winDelayBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("winDelayGet Error : ", error);
    };
};

export { winDelayGet };