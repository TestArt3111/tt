import { Job } from "bull";

import { logger } from "../../logger/logger";
import { gameStartBull } from "../allQueues/allQueues";

const gameStartGet = async (tableId: string) => {

    try {

        logger.log("gameStartGet", { tableId });

        const job: (Job | null) = await gameStartBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("gameStartGet Error : ", error);
    };
};

export { gameStartGet };