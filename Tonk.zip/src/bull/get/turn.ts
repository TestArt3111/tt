import { Job } from "bull";

import { logger } from "../../logger/logger";
import { turnBull } from "../allQueues/allQueues";

const turnGet = async (tableId: string) => {

    try {

        logger.log("turnGet", { tableId });

        const job: (Job | null) = await turnBull.getJob(tableId);

        return job;

    } catch (error: any) {
        logger.errorLog("turnGet Error : ", error);
    };
};

export { turnGet };