import { Job } from "bull";

import { logger } from "../../logger/logger";
import { disconnectUserBull } from "../allQueues/allQueues";

const disconnectUserRemove = async (userId: string) => {

    try {

        logger.log("disconnectUserRemove", { userId });

        const job: (Job | null) = await disconnectUserBull.getJob(userId);

        await job?.remove()
            .then(() => logger.log("disconnectUserRemove", `Job Remove ✔ : ${userId}`))
            .catch((error) => logger.errorLog("disconnectUserRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("disconnectUserRemove Error : ", error);
    };
};

export { disconnectUserRemove };