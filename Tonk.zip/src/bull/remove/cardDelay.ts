import { Job } from "bull";

import { logger } from "../../logger/logger";
import { cardDelayBull } from "../allQueues/allQueues";

const cardDelayRemove = async (tableId: string) => {

    try {

        logger.log("cardDelayRemove", { tableId });

        const job: (Job | null) = await cardDelayBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("cardDelayRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("cardDelayRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("cardDelayRemove Error : ", error);
    };
};

export { cardDelayRemove };