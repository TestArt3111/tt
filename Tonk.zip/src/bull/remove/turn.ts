import { Job } from "bull";

import { logger } from "../../logger/logger";
import { turnBull } from "../allQueues/allQueues";

const turnRemove = async (tableId: string) => {

    try {

        logger.log("turnRemove", { tableId });

        const job: (Job | null) = await turnBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("turnRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("turnRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("turnRemove Error : ", error);
    };
};

export { turnRemove };