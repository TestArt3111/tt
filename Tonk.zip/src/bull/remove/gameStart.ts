import { Job } from "bull";

import { logger } from "../../logger/logger";
import { gameStartBull } from "../allQueues/allQueues";

const gameStartRemove = async (tableId: string) => {

    try {

        logger.log("gameStartRemove", { tableId });

        const job: (Job | null) = await gameStartBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("gameStartRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("gameStartRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("gameStartRemove Error : ", error);
    };
};

export { gameStartRemove };