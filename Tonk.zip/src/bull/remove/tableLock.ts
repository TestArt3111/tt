import { Job } from "bull";

import { logger } from "../../logger/logger";
import { tableLockBull } from "../allQueues/allQueues";

const tableLockRemove = async (tableId: string) => {

    try {

        logger.log("tableLockRemove", { tableId });

        const job: (Job | null) = await tableLockBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("tableLockRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("tableLockRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("tableLockRemove Error : ", error);
    };
};

export { tableLockRemove };