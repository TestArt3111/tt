import { Job } from "bull";

import { logger } from "../../logger/logger";
import { winDelayBull } from "../allQueues/allQueues";

const winDelayRemove = async (tableId: string) => {

    try {

        logger.log("winDelayRemove", { tableId });

        const job: (Job | null) = await winDelayBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("winDelayRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("winDelayRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("winDelayRemove Error : ", error);
    };
};

export { winDelayRemove };