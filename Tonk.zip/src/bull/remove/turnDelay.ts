import { Job } from "bull";

import { logger } from "../../logger/logger";
import { turnDelayBull } from "../allQueues/allQueues";

const turnDelayRemove = async (tableId: string) => {

    try {

        logger.log("turnDelayRemove", { tableId });

        const job: (Job | null) = await turnDelayBull.getJob(tableId);

        await job?.remove()
            .then(() => logger.log("turnDelayRemove", `Job Remove ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("turnDelayRemove", `Job Remove Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("turnDelayRemove Error : ", error);
    };
};

export { turnDelayRemove };