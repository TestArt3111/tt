import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { winDelayExecute } from "../../common/processExecution/winDelay";

const winDelayProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("winDelayProcess", job.data);

        done();

        await winDelayExecute(job?.data);
        
    } catch (error: any) {
        logger.errorLog("winDelayProcess Error : ", error);
    };
};

export { winDelayProcess }; 