import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { tableLockExecute } from "../../common/processExecution/tableLock";

const tableLockProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("tableLockProcess", job.data);

        done();

        await tableLockExecute(job?.data);

    } catch (error: any) {
        logger.errorLog("tableLockProcess Error : ", error);
    };
};

export { tableLockProcess };