import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { cardDelayExecute } from "../../common/processExecution/cardDelay";

const cardDelayProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("cardDelayProcess", job.data);

        done();

        await cardDelayExecute(job?.data);

    } catch (error: any) {
        logger.errorLog("cardDelayProcess Error : ", error);
    };
};

export { cardDelayProcess };