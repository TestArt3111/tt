import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { disconnectUserExecute } from "../../common/processExecution/disconnectUser";

const disconnectUserProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("disconnectUserProcess", job.data);

        done();

        await disconnectUserExecute(job?.data);

    } catch (error: any) {
        logger.errorLog("disconnectUserProcess Error : ", error);
    };
};

export { disconnectUserProcess };