import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { turnDelayExecute } from "../../common/processExecution/turnDelay";

const turnDelayProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("turnDelayProcess", job.data);

        done();

        await turnDelayExecute(job?.data);

    } catch (error: any) {
        logger.errorLog("turnDelayProcess Error : ", error);
    };
};

export { turnDelayProcess };