import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { turnExecute } from "../../common/processExecution/turn";

const turnProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("turnProcess", job.data);

        done();

        await turnExecute(job.data);

    } catch (error: any) {
        logger.errorLog("turnProcess Error : ", error);
    };
};

export { turnProcess };