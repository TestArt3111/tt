import { DoneCallback, Job } from "bull";

import { logger } from "../../logger/logger";
import { gameStartExecute } from "../../common/processExecution/gameStart";

const gameStartProcess = async (job: Job, done: DoneCallback) => {

    try {

        logger.log("gameStartProcess", job.data);

        done();

        await gameStartExecute(job.data);

    } catch (error: any) {
        logger.errorLog("gameStartProcess Error : ", error);
    };
};

export { gameStartProcess };