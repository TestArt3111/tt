import { config } from "../../config";
import { logger } from "../../logger/logger";
import { gameStartRemove } from "../remove/gameStart";
import { gameStartBull } from "../allQueues/allQueues";
import { gameStartProcess } from "../process/gameStart";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const gameStartAdd = async (tableId: string) => {

    try {

        logger.log("gameStartAdd", { tableId });

        await gameStartRemove(tableId);

        const options = await dummyBullAddOptions(config.gamePlay.GAME_START_TIMER, tableId);

        await gameStartBull.add({ tableId }, options)
            .then(() => logger.log("gameStartAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("gameStartAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("gameStartAdd Error : ", error);
    };
};

gameStartBull.process(gameStartProcess);

export { gameStartAdd };