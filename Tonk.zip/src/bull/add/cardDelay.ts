import { logger } from "../../logger/logger";
import { cardDelayRemove } from "../remove/cardDelay";
import { cardDelayBull } from "../allQueues/allQueues";
import { cardDelayProcess } from "../process/cardDelay";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const cardDelayAdd = async (tableId: string) => {

    try {

        logger.log("cardDelayAdd", { tableId });

        await cardDelayRemove(tableId);

        const options = await dummyBullAddOptions(1, tableId);

        await cardDelayBull.add({ tableId }, options)
            .then(() => logger.log("cardDelayAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("cardDelayAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("cardDelayAdd Error : ", error);
    };
};

cardDelayBull.process(cardDelayProcess);

export { cardDelayAdd };