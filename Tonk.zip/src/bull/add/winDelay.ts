import { logger } from "../../logger/logger";
import { winDelayRemove } from "../remove/winDelay";
import { winDelayBull } from "../allQueues/allQueues";
import { winDelayProcess } from "../process/winDelay";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const winDelayAdd = async (tableId: string, bootValue: number, delay: number) => {

    try {

        logger.log("winDelayAdd", { tableId, bootValue, delay });

        await winDelayRemove(tableId);

        const options = await dummyBullAddOptions(delay, tableId);

        await winDelayBull.add({ tableId, bootValue }, options)
            .then(() => logger.log("winDelayAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("winDelayAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("winDelayAdd Error : ", error);
    };
};

winDelayBull.process(winDelayProcess);

export { winDelayAdd };