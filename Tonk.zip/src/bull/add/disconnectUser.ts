import { config } from "../../config";
import { logger } from "../../logger/logger";
import { disconnectUserBull } from "../allQueues/allQueues";
import { disconnectUserRemove } from "../remove/disconnectUser";
import { disconnectUserProcess } from "../process/disconnectUser";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const disconnectUserAdd = async (userId: string, tableId: string, bootValue: number) => {

    try {

        logger.log("disconnectUserAdd", { userId, tableId, bootValue });

        await disconnectUserRemove(userId);

        const options = await dummyBullAddOptions(config.gamePlay.RETURN_TO_TABLE_TIMER, userId);

        await disconnectUserBull.add({ userId, tableId, bootValue }, options)
            .then(() => logger.log("disconnectUserAdd", `Job Add ✔ : ${userId}`))
            .catch((error) => logger.errorLog("disconnectUserAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("disconnectUserAdd Error : ", error);
    };
};

disconnectUserBull.process(disconnectUserProcess)

export { disconnectUserAdd };