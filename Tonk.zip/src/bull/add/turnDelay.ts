import { logger } from "../../logger/logger";
import { turnDelayRemove } from "../remove/turnDelay";
import { turnDelayBull } from "../allQueues/allQueues";
import { turnDelayProcess } from "../process/turnDelay";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const turnDelayAdd = async (tableId: string, currentTurn: number, delay: number) => {

    try {

        logger.log("turnDelayAdd", { tableId, currentTurn, delay });

        await turnDelayRemove(tableId);

        const options = await dummyBullAddOptions(delay, tableId);

        await turnDelayBull.add({ tableId, currentTurn }, options)
            .then(() => logger.log("turnDelayAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("turnDelayAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("turnDelayAdd Error : ", error);
    };
};

turnDelayBull.process(turnDelayProcess);

export { turnDelayAdd };