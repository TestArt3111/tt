import { config } from "../../config";
import { turnRemove } from "../remove/turn";
import { logger } from "../../logger/logger";
import { turnProcess } from "../process/turn";
import { turnBull } from "../allQueues/allQueues";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const turnAdd = async (tableId: string, currentTurn: number) => {

    try {

        logger.log("turnAdd", { tableId, currentTurn });

        await turnRemove(tableId);

        const options = await dummyBullAddOptions(config.gamePlay.USER_TURN_TIMER, tableId);

        await turnBull.add({ tableId, currentTurn }, options)
            .then(() => logger.log("turnAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("turnAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("turnAdd Error : ", error);
    };
};

turnBull.process(turnProcess)

export { turnAdd };