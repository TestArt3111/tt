import { config } from "../../config";
import { logger } from "../../logger/logger";
import { tableLockRemove } from "../remove/tableLock";
import { tableLockBull } from "../allQueues/allQueues";
import { tableLockProcess } from "../process/tableLock";
import { dummyBullAddOptions } from "../../common/dummyData/bullAddOptions";

const tableLockAdd = async (tableId: string) => {

    try {

        logger.log("tableLockAdd", { tableId });

        await tableLockRemove(tableId);

        const options = await dummyBullAddOptions(config.gamePlay.TABLE_LOCK_TIMER, tableId);

        await tableLockBull.add({ tableId }, options)
            .then(() => logger.log("tableLockAdd", `Job Add ✔ : ${tableId}`))
            .catch((error) => logger.errorLog("tableLockAdd", `Job Add Error ✖ : ${error}`))

    } catch (error: any) {
        logger.errorLog("tableLockAdd Error : ", error);
    };
};

tableLockBull.process(tableLockProcess);

export { tableLockAdd };