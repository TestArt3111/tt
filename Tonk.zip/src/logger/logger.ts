import winston from "winston";
import { config } from "../config";

const winstonLogger = winston.createLogger({

    format: winston.format.combine(
        winston.format.simple(),
        winston.format.printf(info => `${info.level} : ${info.message}\n.`)
    ),
    transports: [new winston.transports.Console()]

});

const indianTime = () => {

    const utcDate = new Date();

    const istDate = new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        year: "numeric", month: "numeric", day: "numeric",
        hour: "numeric", minute: "numeric", second: "numeric",
    }).format(utcDate);

    return `${istDate} ${utcDate.getMilliseconds().toString().padStart(3, "0")}`;

};

const log = (path: string, data: any, strict?: boolean) => { if (config.gamePlay.LOG || strict) { winstonLogger.info(`${indianTime()} >> Path : ${path} >> Data : ${JSON.stringify(data)}`); }; };

const errorLog = (path: string, error: any) => { winstonLogger.error(`${indianTime()} >> Path : ${path}${error.stack}`); };

const logger = { log, errorLog };

export { logger };