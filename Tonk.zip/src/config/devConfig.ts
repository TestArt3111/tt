import { ConfigInterface } from "../interfaces/config";

const devConfig: ConfigInterface = Object.freeze({

    redis: Object.freeze({

        // ^ Redis
        REDIS_HOST: "127.0.0.1",
        REDIS_PORT: 6379,
        REDIS_PASSWORD: "",
        REDIS_DATABASE_NUMBER: 2

    }),

    redisPubSub: Object.freeze({

        // ^ Redis Pub Sub
        PUBSUB_REDIS_HOST: "127.0.0.1",
        PUBSUB_REDIS_PORT: 6379,
        PUBSUB_REDIS_PASSWORD: "",
        PUBSUB_REDIS_DATABASE_NUMBER: 2

    }),

    mongoUrl: "mongodb://tonk-multiplayer-nodejs:VosPEzeyOqoPrUcrAdre@172.20.12.15:27017/tonk-multiplayer-nodejs",

    serverPort: 8000,

    keyPath: "",
    certPath: "",

    jwtSecretKey: "Arya",

    gamePlay: Object.freeze({

        LOG: true,

        MAX_USERS: 3,
        DISTRIBUTE_CARDS_LIMIT: 5,
        TURN_MISS_COUNT: 3,

        // ^ Timers

        GAME_START_TIMER: 10,
        TABLE_LOCK_TIMER: 7,
        USER_TURN_TIMER: 30,
        RETURN_TO_TABLE_TIMER: 15,

        // ^ Card Points

        KING_POINT: 10,
        QUEEN_POINT: 10,
        JACK_POINT: 10,

        AUTO_WIN: false,
        AUTO_WIN_SCORES: [
            1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
            11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
            21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
            31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
            41, 42, 43, 44, 45, 46, 47, 48, 49, 50
        ],

        TONK_OUT_PENALTY: false,
        KNOCK_PENALTY: true,

    }),

});

export { devConfig };