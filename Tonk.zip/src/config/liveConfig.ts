import { ConfigInterface } from "../interfaces/config";

const liveConfig: ConfigInterface = Object.freeze({

    redis: Object.freeze({

        // ^ Redis
        REDIS_HOST: process.env.REDIS_HOST ? process.env.REDIS_HOST : "127.0.0.1",
        REDIS_PORT: process.env.REDIS_PORT ? Number(process.env.REDIS_PORT) : 6379,
        REDIS_PASSWORD: process.env.REDIS_PASSWORD ? process.env.REDIS_PASSWORD : "",
        REDIS_DATABASE_NUMBER: process.env.REDIS_DATABASE_NUMBER ? Number(process.env.REDIS_DATABASE_NUMBER) : 2

    }),

    redisPubSub: Object.freeze({

        // ^ Redis Pub Sub
        PUBSUB_REDIS_HOST: process.env.PUBSUB_REDIS_HOST ? process.env.PUBSUB_REDIS_HOST : "127.0.0.1",
        PUBSUB_REDIS_PORT: process.env.PUBSUB_REDIS_PORT ? Number(process.env.PUBSUB_REDIS_PORT) : 6379,
        PUBSUB_REDIS_PASSWORD: process.env.PUBSUB_REDIS_PASSWORD ? process.env.PUBSUB_REDIS_PASSWORD : "",
        PUBSUB_REDIS_DATABASE_NUMBER: process.env.PUBSUB_REDIS_DATABASE_NUMBER ? Number(process.env.PUBSUB_REDIS_DATABASE_NUMBER) : 2

    }),

    mongoUrl: process.env.MONGO_URL ? process.env.MONGO_URL : "",

    serverPort: process.env.SERVER_PORT ? Number(process.env.SERVER_PORT) : 8000,

    keyPath: process.env.SERVER_KEY_PATH ? process.env.SERVER_KEY_PATH : "",
    certPath: process.env.SERVER_CERT_PATH ? process.env.SERVER_CERT_PATH : "",

    jwtSecretKey: process.env.JWT_SECRET_KEY ? process.env.JWT_SECRET_KEY : "Arya",

    gamePlay: Object.freeze({

        LOG: true,

        MAX_USERS: 3,
        DISTRIBUTE_CARDS_LIMIT: 5,
        TURN_MISS_COUNT: 3,

        // ^ Timers

        GAME_START_TIMER: 10,
        TABLE_LOCK_TIMER: 7,
        USER_TURN_TIMER: 25,
        RETURN_TO_TABLE_TIMER: 30,

        // ^ Card Points

        KING_POINT: 10,
        QUEEN_POINT: 10,
        JACK_POINT: 10,

        AUTO_WIN: false,
        AUTO_WIN_SCORES: [11, 30, 35, 37, 40, 49],

        TONK_OUT_PENALTY: false,
        KNOCK_PENALTY: true,

    }),

});

export { liveConfig };