import { devConfig } from "./devConfig";
import { liveConfig } from "./liveConfig";
import { CONSTANTS } from "./../constants";

const config = process.env.ENVIRONMENT === CONSTANTS.COMMON.LIVE_ENVIRONMENT ? liveConfig : devConfig;

export { config };