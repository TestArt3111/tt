"use strict";
console.log("Start with indes");
Object.defineProperty(exports, "__esModule", { value: true });
require("dotenv/config");
const logger_1 = require("./src/logger/logger");
const init_1 = require("./src/connection/init");
(0, init_1.initialize)();
process.on("uncaughtException", (error) => {
    logger_1.logger.errorLog("uncaughtException : Error : ", error);
});
process.on("unhandledRejection", (response, error) => {
    logger_1.logger.errorLog("unhandledRejection : response : ", response);
    logger_1.logger.errorLog("unhandledRejection: error : ", error);
});
